import asyncio
import logging
import discord
from discord.ext import commands

from config import DISCORD_TOKEN, LOG_LEVEL, assert_runtime_config
from http_client import close_session
from memory import flush_memory_save

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

async def main() -> None:
    assert_runtime_config()
    try:
        async with bot:
            await bot.load_extension("commands")
            await bot.load_extension("events")
            await bot.start(DISCORD_TOKEN)
    finally:
        # Persist any debounced conversation memory before shutting down.
        await flush_memory_save()
        await close_session()


if __name__ == "__main__":
    asyncio.run(main())
