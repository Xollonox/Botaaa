"""Focused regressions for Bot1 command and memory safety."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

bot1_dir = Path(__file__).parent.parent
sys.path.insert(0, str(bot1_dir))

import commands as bot_commands
import config
import events
import memory
import persona
import stats


def test_only_explicit_special_user_is_global_reset_user() -> None:
    user = SimpleNamespace(id=42)
    other_user = SimpleNamespace(id=99)
    with patch.object(bot_commands, "SPECIAL_USER_ID", 42):
        assert bot_commands.is_special_user(user)
        assert not bot_commands.is_special_user(other_user)


def test_send_discord_text_disables_mentions_by_default() -> None:
    calls = []

    async def send(*args, **kwargs):
        calls.append((args, kwargs))
        return SimpleNamespace(id=1)

    asyncio.run(bot_commands.send_discord_text(send, "@everyone " + "x" * 2_100))

    assert len(calls) == 2
    for _, kwargs in calls:
        allowed = kwargs["allowed_mentions"]
        assert not allowed.everyone
        assert not allowed.users
        assert not allowed.roles
        assert not allowed.replied_user


def test_invalid_channel_settings_are_rejected_before_persistence() -> None:
    isolated_memory = {"users": {}, "channels": {}}
    with patch.object(memory, "BOT_MEMORY", isolated_memory):
        try:
            asyncio.run(memory.set_language_setting(7, "anything"))
        except ValueError as error:
            assert str(error) == "unsupported language setting"
        else:
            raise AssertionError("invalid language setting was accepted")

    assert isolated_memory["channels"] == {}


def test_prompt_context_has_a_hard_size_bound() -> None:
    isolated_memory = {
        "users": {
            "user:1:dm": {
                "lines": [f"U: {'x' * 300}" for _ in range(200)],
                "summary": "s" * 5_000,
                "topic": "topic",
                "msg_count": 0,
            }
        },
        "channels": {},
    }
    with patch.object(memory, "BOT_MEMORY", isolated_memory):
        prompt = memory.add_memory_to_prompt(1, "y" * 10_000)

    assert len(prompt) <= memory.MAX_PROMPT_CONTEXT_CHARS
    assert "[truncated]" in prompt


def test_relation_is_persisted_and_scoped_to_the_conversation() -> None:
    isolated_memory = {"users": {}, "channels": {}}
    with (
        patch.object(memory, "BOT_MEMORY", isolated_memory),
        patch.object(memory, "_save_json_file_async", AsyncMock()) as save,
    ):
        asyncio.run(persona.set_roasting(7, guild_id=10, channel_id=20))
        assert persona.get_relation(7, guild_id=10, channel_id=20) == "roasting"
        assert persona.get_relation(7, guild_id=10, channel_id=21) == "friend"
        assert persona.get_relation(7, guild_id=None, channel_id=20) == "friend"

    save.assert_awaited_once()


def test_daily_stats_roll_over_at_utc_day_boundary() -> None:
    from datetime import datetime, timedelta, timezone

    now = datetime(2026, 1, 2, tzinfo=timezone.utc)
    with (
        patch.object(stats, "_stats_day", (now - timedelta(days=1)).date()),
        patch.object(stats, "messages_processed", 9),
        patch.object(stats, "messages_processed_today", 4),
        patch.object(stats, "active_users_today", {1, 2}),
    ):
        stats.record_message(3, now=now)
        assert stats.messages_processed == 10
        assert stats.messages_processed_today == 1
        assert stats.daily_active_user_count(now=now) == 1


def test_prefix_command_is_counted_but_does_not_enter_autonomous_pipeline() -> None:
    bot = SimpleNamespace(
        get_context=AsyncMock(return_value=SimpleNamespace(valid=True)),
        process_commands=AsyncMock(),
    )
    cog = events.EventsCog(bot)
    message = SimpleNamespace(author=SimpleNamespace(bot=False, id=1))
    with patch.object(stats, "record_message") as record:
        asyncio.run(cog.on_message(message))

    record.assert_called_once_with(1)
    bot.process_commands.assert_awaited_once_with(message)


def test_config_rejects_a_keyed_provider_with_an_invalid_url() -> None:
    with (
        patch.object(config, "DISCORD_TOKEN", "token"),
        patch.object(
            config,
            "_llm_provider_settings",
            return_value=(("Ollama", True, "not-a-url", "model"),),
        ),
    ):
        try:
            config.assert_runtime_config()
        except RuntimeError as error:
            assert "Ollama has an invalid base URL" in str(error)
        else:
            raise AssertionError("invalid configured provider was accepted")
