"""Behavioral tests for Bot1's persistent conversation memory."""

from __future__ import annotations

import asyncio
import sys
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

bot1_dir = Path(__file__).parent.parent
sys.path.insert(0, str(bot1_dir))

import memory


class TestRememberLine(unittest.TestCase):
    def setUp(self) -> None:
        self.bot_memory = {"users": {}, "channels": {}}
        self.save = AsyncMock()
        self.schedule = MagicMock()
        self.settings = {"max_user_memory_items": 80}
        self.memory_patch = patch.object(memory, "BOT_MEMORY", self.bot_memory)
        self.save_patch = patch.object(memory, "_save_json_file_async", self.save)
        self.schedule_patch = patch.object(memory, "schedule_memory_save", self.schedule)
        self.settings_patch = patch.object(memory, "BOT_SETTINGS", self.settings)
        self.memory_patch.start()
        self.save_patch.start()
        self.schedule_patch.start()
        self.settings_patch.start()

    def tearDown(self) -> None:
        self.memory_patch.stop()
        self.save_patch.stop()
        self.schedule_patch.stop()
        self.settings_patch.stop()

    def test_backend_error_is_not_persisted(self) -> None:
        asyncio.run(
            memory.remember_line(
                111111111,
                "B",
                "I could not reach the AI backend right now due to network issues",
            )
        )
        self.save.assert_not_called()
        self.schedule.assert_not_called()
        self.assertFalse(self.bot_memory["users"])

    def test_normal_lines_are_trimmed_and_saved_in_their_scope(self) -> None:
        asyncio.run(memory.remember_line(333, "U", "x" * 500, 888, 999))
        state = self.bot_memory["users"]["user:333:guild:888:chan:999"]
        self.assertEqual(state["lines"], ["U: " + "x" * 300])
        self.assertEqual(state["msg_count"], 1)
        # Conversation writes are debounced, not written synchronously...
        self.schedule.assert_called_once_with()
        self.save.assert_not_called()
        # ...but an explicit flush persists immediately.
        asyncio.run(memory.flush_memory_save())
        self.save.assert_awaited_once_with(memory.MEMORY_FILE, self.bot_memory)

    def test_memory_is_not_shared_between_users_or_channels(self) -> None:
        asyncio.run(memory.remember_line(1, "U", "private guild one", 10, 20))
        other_user = memory.add_memory_to_prompt(2, "hello", guild_id=10, channel_id=20)
        other_channel = memory.add_memory_to_prompt(1, "hello", guild_id=10, channel_id=21)

        self.assertNotIn("private guild one", other_user)
        self.assertNotIn("private guild one", other_channel)


if __name__ == "__main__":
    unittest.main()
