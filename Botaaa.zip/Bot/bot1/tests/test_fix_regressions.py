"""Regression tests for the Bot1 bug-fix batch (memory, reset, triggers)."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

bot1_dir = Path(__file__).parent.parent
sys.path.insert(0, str(bot1_dir))

import image  # noqa: E402
import memory  # noqa: E402


def test_legacy_user_states_migrate_for_stats_aggregation() -> None:
    """Fix 2: plain-list legacy user states are normalized like _scope_state."""
    legacy = {
        "user:1:dm": ["U: hello", "B: hi"],
        "user:2:guild:7:chan:9": {
            "lines": ["U: ok"],
            "summary": "",
            "topic": "",
            "msg_count": 1,
        },
    }
    memory._migrate_legacy_user_states(legacy)

    migrated = legacy["user:1:dm"]
    assert migrated["lines"] == ["U: hello", "B: hi"]
    assert migrated["msg_count"] == 0
    assert legacy["user:2:guild:7:chan:9"]["msg_count"] == 1
    # The /stats aggregation in commands.py iterates state.get("lines", []);
    # it must no longer hit AttributeError on list-typed states.
    total = sum(len(state.get("lines", [])) for state in legacy.values())
    assert total == 3


async def test_reset_my_memory_clears_all_guild_channel_scopes() -> None:
    """Fix 6: guild reset removes every per-channel scope for that user."""
    isolated = {
        "users": {
            "user:5:guild:7": {"lines": ["U: a"]},
            "user:5:guild:7:chan:1": {"lines": ["U: b"]},
            "user:5:guild:7:chan:2": {"lines": ["U: c"]},
            "user:5:guild:70:chan:3": {"lines": ["U: keep me"]},
            "user:5:dm": {"lines": ["U: dm stays"]},
            "user:6:guild:7:chan:1": {"lines": ["U: other user"]},
        },
        "channels": {},
    }
    with (
        patch.object(memory, "BOT_MEMORY", isolated),
        patch.object(memory, "SPECIAL_USER_ID", None),
        patch.object(memory, "_save_json_file_async", AsyncMock()),
    ):
        await memory.clear_user_memory(5, guild_id=7, channel_id=1)

    assert set(isolated["users"]) == {
        "user:5:guild:70:chan:3",
        "user:5:dm",
        "user:6:guild:7:chan:1",
    }


async def test_reset_my_memory_in_dm_clears_dm_scope_only() -> None:
    """Fix 6: DM reset behavior is unchanged."""
    isolated = {
        "users": {
            "user:5:dm": {"lines": ["U: x"]},
            "5": {"lines": ["U: legacy"]},
            "user:5:guild:7:chan:1": {"lines": ["U: guild stays"]},
        },
        "channels": {},
    }
    with (
        patch.object(memory, "BOT_MEMORY", isolated),
        patch.object(memory, "SPECIAL_USER_ID", None),
        patch.object(memory, "_save_json_file_async", AsyncMock()),
    ):
        await memory.clear_user_memory(5, guild_id=None, channel_id=1)

    assert set(isolated["users"]) == {"user:5:guild:7:chan:1"}


def test_image_trigger_prompt_survives_extra_spacing_and_punctuation() -> None:
    """Fix 8: the prompt is sliced from the original text, not normalized text."""
    assert image.maybe_image_trigger_prompt("create  image of a cat") == "of a cat"
    assert image.maybe_image_trigger_prompt("Create image: a robot!") == "a robot!"
    assert image.maybe_image_trigger_prompt("imagine: a dragon") == "a dragon"
    assert image.maybe_image_trigger_prompt("imagine in a meadow") == "in a meadow"
    assert image.maybe_image_trigger_prompt("imagine") == (
        "Create a high-quality artistic image."
    )
    assert image.maybe_image_trigger_prompt("hello there") is None


async def test_summary_update_keeps_lines_remembered_during_llm_call() -> None:
    """Fix 1: lines appended while the summary LLM call runs are not dropped."""
    isolated = {"users": {}, "channels": {}}
    llm_started = asyncio.Event()
    release_llm = asyncio.Event()

    async def slow_summary(**_kwargs):
        llm_started.set()
        await release_llm.wait()
        return "They discussed testing."

    with (
        patch.object(memory, "BOT_MEMORY", isolated),
        patch.object(memory, "SPECIAL_USER_ID", None),
        patch.object(memory, "BOT_SETTINGS", {"max_user_memory_items": 150}),
        patch.object(memory, "schedule_memory_save", MagicMock()),
        patch.object(memory, "_save_json_file_async", AsyncMock()),
        patch("llm.chat_with_fallback", side_effect=slow_summary),
    ):
        state = memory._scope_state(1)
        state["lines"] = [f"U: line {i}" for i in range(8)]
        task = asyncio.create_task(memory.update_conversation_summary(1))
        await llm_started.wait()
        # Two more messages are remembered while the summary is in flight.
        await memory.remember_line(1, "U", "concurrent one")
        await memory.remember_line(1, "B", "concurrent two")
        release_llm.set()
        await task

    state = isolated["users"]["user:1:dm"]
    assert state["summary"] == "They discussed testing."
    assert state["lines"] == [
        "U: line 4",
        "U: line 5",
        "U: line 6",
        "U: line 7",
        "U: concurrent one",
        "B: concurrent two",
    ]
