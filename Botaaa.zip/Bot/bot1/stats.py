"""In-process bot statistics with UTC-day rollover."""

from datetime import date, datetime, timezone

bot_start_time = datetime.now(timezone.utc)
messages_processed = 0
messages_processed_today = 0
active_users_today: set[int] = set()
_stats_day: date = datetime.now(timezone.utc).date()


def _rollover_if_needed(now: datetime | None = None) -> None:
    """Clear counters advertised as "today" when the UTC calendar day changes."""
    global _stats_day, messages_processed_today
    today = (now or datetime.now(timezone.utc)).date()
    if today != _stats_day:
        _stats_day = today
        messages_processed_today = 0
        active_users_today.clear()


def record_message(user_id: int, now: datetime | None = None) -> None:
    """Record one received user message."""
    global messages_processed, messages_processed_today
    _rollover_if_needed(now)
    messages_processed += 1
    messages_processed_today += 1
    active_users_today.add(user_id)


def daily_active_user_count(now: datetime | None = None) -> int:
    _rollover_if_needed(now)
    return len(active_users_today)
