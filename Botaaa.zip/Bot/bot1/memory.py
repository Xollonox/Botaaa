import asyncio
import json
import logging
import os
import tempfile
from copy import deepcopy
from typing import Optional

from config import MEMORY_FILE, SETTINGS_FILE, SPECIAL_USER_ID
from llm import LLM_ERROR_SENTINELS

logger = logging.getLogger("misskim")

# Character limits keep memory and lore from growing into an unbounded provider
# request. They are deliberately conservative and independent of provider tokenizers.
MAX_PROMPT_CONTEXT_CHARS = 9_000
MAX_CURRENT_PROMPT_CHARS = 3_000
MAX_SUMMARY_CHARS = 1_000
MAX_MEMORY_CONTEXT_CHARS = 4_500

_memory_lock = asyncio.Lock()

# ── Channel settings (language and mood only) ─────────────────────────
#
# Conversation content is intentionally per-user. Do not put messages or bot
# replies in channel state: everyone who can talk in a channel must not receive
# another user's conversation as LLM context.

def _load_json_file(path: str, default: dict) -> dict:
    try:
        if not os.path.exists(path):
            return default
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else default
    except Exception:
        logger.exception("Failed to load JSON file: %s", path)
        return default


def _save_json_file(path: str, data: dict) -> None:
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    tmp_name = ""
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=directory,
            delete=False,
        ) as f:
            tmp_name = f.name
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except Exception:
        logger.exception("Failed to save JSON file: %s", path)
        if tmp_name:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass


async def _save_json_file_async(path: str, data: dict) -> None:
    async with _memory_lock:
        # Serialize an immutable snapshot: other message coroutines may mutate
        # BOT_MEMORY while the blocking JSON write runs in the executor.
        snapshot = deepcopy(data)
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, _save_json_file, path, snapshot)


# Debounced memory persistence. remember_line() runs on every chat message,
# and a full deepcopy + JSON dump per message blocks the event loop as memory
# grows, so conversation writes are batched. Explicit actions (settings,
# resets, relation/summary updates) still save promptly via flush_memory_save.
# On crash, at most the debounce window of conversation lines is lost.
_MEMORY_SAVE_DEBOUNCE_SECONDS = 5.0
_memory_save_handle: asyncio.TimerHandle | None = None


async def _persist_memory_now() -> None:
    try:
        await _save_json_file_async(MEMORY_FILE, BOT_MEMORY)
    except Exception:
        logger.exception("Memory save failed")


def schedule_memory_save() -> None:
    """Persist BOT_MEMORY soon, collapsing bursts of remember_line() calls."""
    global _memory_save_handle
    if _memory_save_handle is not None:
        return

    def _fire() -> None:
        global _memory_save_handle
        _memory_save_handle = None
        asyncio.ensure_future(_persist_memory_now())

    _memory_save_handle = asyncio.get_running_loop().call_later(
        _MEMORY_SAVE_DEBOUNCE_SECONDS, _fire
    )


async def flush_memory_save() -> None:
    """Persist BOT_MEMORY now, canceling any pending debounced save."""
    global _memory_save_handle
    if _memory_save_handle is not None:
        _memory_save_handle.cancel()
        _memory_save_handle = None
    await _persist_memory_now()


def _migrate_legacy_user_states(users: dict) -> None:
    """Normalize legacy plain-list user states in place.

    _scope_state performs the same migration lazily on write access; doing it
    at load keeps read-only paths (e.g. the /stats aggregation) safe on legacy
    memory files.
    """
    for scope_key, state in list(users.items()):
        if isinstance(state, list):
            users[scope_key] = {
                "lines": state,
                "summary": "",
                "topic": "",
                "msg_count": 0,
            }


BOT_MEMORY: dict = _load_json_file(MEMORY_FILE, {"users": {}, "channels": {}})
_migrate_legacy_user_states(BOT_MEMORY.get("users", {}))
# Drop legacy shared transcripts on load. Channel settings remain intact, while
# any historical conversational text can no longer be injected into prompts.
for _channel_state in BOT_MEMORY.get("channels", {}).values():
    if isinstance(_channel_state, dict):
        _channel_state.pop("conversation", None)

BOT_SETTINGS: dict = _load_json_file(
    SETTINGS_FILE,
    {"max_user_memory_items": 150, "summary_every": 10},
)


def _memory_limit(key: str, fallback: int) -> int:
    try:
        return max(1, int(BOT_SETTINGS.get(key, fallback)))
    except Exception:
        return fallback


def _memory_scope_key(
    user_id: int,
    guild_id: Optional[int],
    channel_id: Optional[int] = None,
) -> str:
    user_prefix = "special" if (SPECIAL_USER_ID is not None and user_id == SPECIAL_USER_ID) else "user"
    if guild_id is None:
        return f"{user_prefix}:{user_id}:dm"
    if channel_id is not None:
        return f"{user_prefix}:{user_id}:guild:{guild_id}:chan:{channel_id}"
    return f"{user_prefix}:{user_id}:guild:{guild_id}"


def _scope_state(
    user_id: int,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> dict:
    users = BOT_MEMORY.setdefault("users", {})
    scope_key = _memory_scope_key(user_id, guild_id, channel_id)
    state = users.setdefault(scope_key, {})
    if isinstance(state, list):
        state = {"lines": state, "summary": "", "topic": "", "msg_count": 0}
        users[scope_key] = state
    state.setdefault("lines", [])
    state.setdefault("summary", "")
    state.setdefault("topic", "")
    state.setdefault("msg_count", 0)
    state.setdefault("relation", "friend")
    return state


async def remember_line(
    user_id: int,
    prefix: str,
    line: str,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> None:
    cleaned = line.strip()
    if prefix == "B" and any(s in cleaned for s in LLM_ERROR_SENTINELS):
        return
    state = _scope_state(user_id, guild_id, channel_id)
    lines = state["lines"]
    lines.append(f"{prefix}: {cleaned[:300]}")
    state["lines"] = lines[-_memory_limit("max_user_memory_items", 150):]
    state["msg_count"] = state.get("msg_count", 0) + 1
    topic = _detect_topic(lines[-10:])
    if topic:
        state["topic"] = topic
    # Batched persistence: a hard save per message would block the gateway
    # loop. Explicit actions flush promptly; at most the debounce window of
    # lines is lost on crash.
    schedule_memory_save()


def _detect_topic(lines: list) -> str:
    common_topics = {
        "lookism": [
            "lookism", "yeonu", "jinyoung", "red paper", "webtoon", "manhwa", "chapter",
        ],
        "game": [
            "game", "play", "gaming", "rpg", "mmo", "mobile legend", "valorant", "fortnite",
        ],
        "music": [
            "song", "music", "playlist", "album", "artist", "listen", "rap", "hip hop",
            "kpop", "rock",
        ],
        "movie": ["movie", "film", "show", "netflix", "anime", "series", "watch"],
        "food": ["food", "eat", "cook", "recipe", "hungry", "dinner", "lunch", "breakfast"],
        "tech": [
            "code", "coding", "programming", "python", "javascript", "ai", "bot", "api", "app",
        ],
        "life": ["work", "study", "school", "college", "job", "office", "exam", "test"],
        "sports": [
            "sport", "game", "match", "team", "win", "fight", "boxing", "mma",
            "basketball", "football",
        ],
        "relationship": [
            "love", "crush", "date", "girlfriend", "boyfriend", "relationship",
            "heart", "breakup",
        ],
    }
    text = " ".join(lines).lower()
    for topic, keywords in common_topics.items():
        for kw in keywords:
            if kw in text:
                return topic
    return ""


def _clip(text: object, limit: int) -> str:
    """Return a bounded string, marking truncation without splitting callers."""
    value = str(text or "")
    return value if len(value) <= limit else value[: limit - 15] + "… [truncated]"


def add_memory_to_prompt(
    user_id: int,
    user_text: str,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> str:
    """Build a bounded, scope-local context block for an LLM request."""
    state = _scope_state(user_id, guild_id, channel_id)
    lines = state.get("lines", [])
    summary = _clip(state.get("summary", ""), MAX_SUMMARY_CHARS)
    topic = _clip(state.get("topic", ""), 100)
    current = _clip(user_text, MAX_CURRENT_PROMPT_CHARS)
    context_parts = []

    if summary:
        context_parts.append(f"[Conversation so far: {summary}]")
    if topic:
        context_parts.append(f"[Current topic: {topic}]")
    if lines:
        relevant = get_relevant_memories(lines, current, max_items=30)
        selected = []
        used = 0
        # Keep each selected line bounded and stop before context becomes huge.
        for line in relevant:
            line = _clip(line, 300)
            if used + len(line) + 1 > MAX_MEMORY_CONTEXT_CHARS:
                break
            selected.append(line)
            used += len(line) + 1
        if selected:
            context_parts.append("[Recent conversation:\n" + "\n".join(selected) + "]")
    context_parts.append(f"[Now: {current}]")
    # The individual budgets above fit this cap; retain this final guard if a
    # future context part is added.
    return _clip("\n".join(context_parts), MAX_PROMPT_CONTEXT_CHARS)


def get_relevant_memories(
    all_memories: list,
    current_message: str,
    max_items: int = 30,
) -> list:
    if not all_memories:
        return []
    msg_words = set(current_message.lower().split())
    scored = []
    for mem in all_memories:
        mem_words = set(str(mem).lower().split())
        overlap = len(msg_words & mem_words)
        scored.append((overlap, mem))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [m for _, m in scored[:max_items]]


async def update_conversation_summary(
    user_id: int,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> None:
    # Import here to avoid circular import at module load time
    from llm import chat_with_fallback

    state = _scope_state(user_id, guild_id, channel_id)
    lines = list(state.get("lines", []))
    if len(lines) < 4:
        return
    to_summarize = lines[:-4]
    if not to_summarize:
        return
    try:
        summary = await chat_with_fallback(
            system_prompt=(
                "Summarize this conversation in 1 short sentence. "
                "Focus on key topics, opinions, and ongoing context. "
                "Just the summary, no prefix."
            ),
            user_prompt="Conversation:\n" + "\n".join(to_summarize),
        )
        if not any(s in summary for s in LLM_ERROR_SENTINELS):
            state["summary"] = summary.strip()[:300]
            # Messages remembered while the LLM call ran must not be dropped:
            # remove only the summarized prefix from the CURRENT lines,
            # keeping the kept tail plus anything appended during the await.
            keep = lines[-4:]
            current = list(state.get("lines", []))
            for offset in range(len(lines)):
                overlap = lines[offset:]
                if current[: len(overlap)] == overlap:
                    state["lines"] = keep + current[len(overlap):]
                    break
            # If the snapshot no longer prefixes the current lines (concurrent
            # reset/rewrite), leave the current lines untouched instead of
            # discarding fresh messages.
            await flush_memory_save()
    except Exception:
        logger.exception(
            "Conversation summary update failed | user=%s guild=%s channel=%s",
            user_id,
            guild_id,
            channel_id,
        )


def get_relation(
    user_id: int,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> str:
    """Return persisted relationship state for exactly this user conversation."""
    return _scope_state(user_id, guild_id, channel_id).get("relation", "friend")


async def set_relation(
    user_id: int,
    relation: str,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> None:
    if relation not in {"friend", "roasting"}:
        raise ValueError("unsupported relation")
    _scope_state(user_id, guild_id, channel_id)["relation"] = relation
    await flush_memory_save()


async def clear_user_memory(
    user_id: int,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> None:
    users = BOT_MEMORY.setdefault("users", {})
    if guild_id is None:
        # DMs hold a single conversation scope per user.
        users.pop(_memory_scope_key(user_id, guild_id, channel_id), None)
        users.pop(str(user_id), None)
    else:
        # In a guild the user has one scope per channel; reset all of them so
        # 'Reset My Memory' does not leave staler channel memories behind.
        user_prefix = (
            "special"
            if (SPECIAL_USER_ID is not None and user_id == SPECIAL_USER_ID)
            else "user"
        )
        guild_prefix = f"{user_prefix}:{user_id}:guild:{guild_id}"
        for key in [
            k for k in users if k == guild_prefix or k.startswith(guild_prefix + ":")
        ]:
            users.pop(key, None)
    await flush_memory_save()


async def clear_all_memory() -> None:
    BOT_MEMORY["users"] = {}
    BOT_MEMORY["channels"] = {}
    await flush_memory_save()


def _should_summarize(
    user_id: int,
    guild_id: Optional[int] = None,
    channel_id: Optional[int] = None,
) -> bool:
    state = _scope_state(user_id, guild_id, channel_id)
    count = state.get("msg_count", 0)
    every = max(5, int(BOT_SETTINGS.get("summary_every", 10)))
    return count > 0 and count % every == 0


def get_language_setting(channel_id: int) -> str:
    channels = BOT_MEMORY.get("channels", {})
    return channels.get(str(channel_id), {}).get("lang", "auto")


async def set_language_setting(channel_id: int, lang: str) -> None:
    if lang not in {"auto", "en", "hinglish"}:
        raise ValueError("unsupported language setting")
    channels = BOT_MEMORY.setdefault("channels", {})
    chan_data = channels.setdefault(str(channel_id), {})
    chan_data["lang"] = lang
    await flush_memory_save()


def get_mood(channel_id: int) -> str:
    channels = BOT_MEMORY.get("channels", {})
    return channels.get(str(channel_id), {}).get("mood", "calm")


async def set_mood(channel_id: int, mood: str) -> None:
    # Keep persisted state valid even if this function is called outside a
    # Discord command (whose UI choices already constrain the value).
    from persona import VALID_MOODS

    if mood not in VALID_MOODS:
        raise ValueError("unsupported mood setting")
    channels = BOT_MEMORY.setdefault("channels", {})
    chan_data = channels.setdefault(str(channel_id), {})
    chan_data["mood"] = mood
    await flush_memory_save()


def build_full_user_prompt(
    text: str,
    user_id: int,
    guild_id: Optional[int],
    channel_id: int,
) -> str:
    """Build the full user-facing prompt by injecting lore + memories.

    Kept in memory.py so both commands.py and events.py share one copy.
    Imports from persona are deferred to avoid the memory ↔ persona
    circular-import that would arise from a top-level import.
    """
    from persona import build_user_prompt_with_lore  # deferred — persona lazily imports memory

    lore_prompt = build_user_prompt_with_lore(text)
    return add_memory_to_prompt(
        user_id, lore_prompt, guild_id=guild_id, channel_id=channel_id
    )
