from __future__ import annotations

from types import SimpleNamespace

from bot.utils.server_rules import (
    check_battle_channel_allowed,
    check_single_mode_allowed,
    get_configured_announcement_channel_ids,
    get_guild_settings,
)


class _Storage:
    def __init__(self, data: dict) -> None:
        self.data = data

    def load_readonly(self) -> dict:
        return self.data


def _interaction(guild_id: int | None, channel_id: int, data: dict) -> SimpleNamespace:
    return SimpleNamespace(
        guild_id=guild_id,
        channel_id=channel_id,
        client=SimpleNamespace(storage=_Storage(data)),
    )


def test_guild_settings_do_not_leak_between_guilds() -> None:
    data = {
        "server_settings": {"mode": "single", "locked_channel_id": 999},
        "server_settings_by_guild": {
            "1": {"mode": "single", "locked_channel_id": 10, "battle_channel_id": 20},
        },
    }

    assert check_single_mode_allowed(_interaction(1, 10, data))[0] is True
    assert check_single_mode_allowed(_interaction(1, 11, data))[0] is False
    assert check_single_mode_allowed(_interaction(2, 999, data))[0] is True
    assert check_battle_channel_allowed(_interaction(2, 21, data))[0] is True


def test_legacy_settings_are_read_until_guild_scoped_migration() -> None:
    data = {"server_settings": {"mode": "single", "locked_channel_id": 55}}

    settings = get_guild_settings(data, 1)

    assert settings["mode"] == "single"
    assert settings["locked_channel_id"] == 55


def test_background_announcements_use_only_explicit_guild_channels() -> None:
    data = {
        "server_settings": {"announce_channel_id": 999},
        "server_settings_by_guild": {
            "1": {"announce_channel_id": 10},
            "2": {"announce_channel_id": 20},
            "3": {"announce_channel_id": 10},
        },
    }

    assert get_configured_announcement_channel_ids(data) == [10, 20]


def test_empty_scoped_map_keeps_legacy_settings_readable_during_migration() -> None:
    data = {
        "server_settings": {"mode": "single", "locked_channel_id": 55},
        "server_settings_by_guild": {},
    }

    assert get_guild_settings(data, 1)["locked_channel_id"] == 55
