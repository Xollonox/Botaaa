from __future__ import annotations

from bot.utils.alliance_logic import (
    apply_alliance_id_to_gang_members,
    cooldown_remaining,
    get_gang_alliance_id,
)
from bot.utils.war_logic import can_attack, compute_war_score, get_user_active_war, grant_war_rewards, record_attack
from bot.utils.gang_logic import get_user_gang


def _war() -> dict:
    return {
        "phase": "battle",
        "format": 2,
        "gang_a": "ga",
        "gang_b": "gb",
        "participants_a": ["a1", "a2"],
        "participants_b": ["b1", "b2"],
        "attacks": {},
        "attacked_targets": [],
        "pending_attacks": {},
    }


def test_alliance_membership_updates_authoritative_gang_and_profile_state() -> None:
    data = {"gangs": {"g": {"members": ["u"]}}, "players": {"u": {}}}

    apply_alliance_id_to_gang_members(data, "g", "a")

    assert get_gang_alliance_id(data, "g") == "a"
    assert data["players"]["u"]["alliance_id"] == "a"
    apply_alliance_id_to_gang_members(data, "g", None)
    assert get_gang_alliance_id(data, "g") is None
    assert data["players"]["u"]["alliance_id"] is None
    assert cooldown_remaining("not-a-timestamp", 100) == 0


def test_stale_player_gang_pointer_does_not_restore_membership() -> None:
    data = {"players": {"u": {"gang_id": "g"}}, "gangs": {"g": {"members": []}}}
    assert get_user_gang(data, "u") == (None, None)


def test_war_attack_rejects_nonparticipants_and_nonopponents() -> None:
    war = _war()

    assert can_attack(war, "outsider", "b1")[0] is False
    assert can_attack(war, "a1", "a2")[0] is False
    assert can_attack(war, "a1", "b1") == (True, "ok")


def test_record_attack_requires_matching_pending_target_and_is_single_use() -> None:
    war = _war()
    data = {"gang_wars": {"active_wars": {"w": war}, "queue": {}}}

    assert record_attack(data, "w", "a1", "b1", 1, [90], 0, [], True) is False
    war["pending_attacks"]["a1"] = {"target_uid": "b1"}
    assert record_attack(data, "w", "a1", "b1", 1, [90], 0, [], True) is True
    assert war["attacked_targets"] == ["b1"]
    assert "a1" not in war["pending_attacks"]
    assert record_attack(data, "w", "a1", "b2", 1, [90], 0, [], True) is False


def test_war_state_normalizes_ids_on_both_sides_for_lookup_and_score() -> None:
    war = _war()
    war["participants_a"] = [1]
    war["participants_b"] = [2]
    war["attacks"] = {
        "1": {"stars": 2, "percent": 80, "target_uid": "2"},
        "2": {"def_stars": 1, "def_percent": 50, "target_uid": "1"},
    }
    data = {"gang_wars": {"active_wars": {"w": war}, "queue": {}}}

    assert get_user_active_war(data, "2")[2] == "b"
    assert compute_war_score(war, "a") == (3, 130)


def test_record_attack_rejects_an_expired_battle_phase() -> None:
    war = _war()
    war["phase_started_at"] = 1
    war["pending_attacks"]["a1"] = {"target_uid": "b1"}
    data = {"gang_wars": {"active_wars": {"w": war}, "queue": {}}}

    assert record_attack(data, "w", "a1", "b1", 1, [90], 0, [], True) is False
    assert war["attacks"] == {}


def test_war_rewards_are_idempotent_and_update_gang_record() -> None:
    war = _war()
    war["attacks"] = {"a1": {"stars": 1, "percent": 50, "target_uid": "b1"}}
    data = {
        "gang_wars": {"active_wars": {"w": war}, "queue": {}},
        "gangs": {"ga": {}, "gb": {}},
        "players": {"a1": {"user": {"balance": 0}}, "b1": {"user": {"balance": 0}}},
    }

    assert grant_war_rewards(data, "w") is True
    assert grant_war_rewards(data, "w") is False
    assert data["gangs"]["ga"]["wins"] == 1
    assert data["gangs"]["gb"]["losses"] == 1
    assert data["players"]["a1"]["user"]["balance"] == 500
