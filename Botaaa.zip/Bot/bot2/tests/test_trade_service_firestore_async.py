"""Regression tests for Firestore-backed trade service adapters."""

from __future__ import annotations

import asyncio
import threading

from bot.data import firestore_trade_repo
from bot.data.firestore_trade_repo import FirestoreTradeRepository
from bot.services.trade_service import TradeService


class _Repo:
    async def append_history(self, row: dict) -> None:
        self.row = row


class _Storage:
    def __init__(self) -> None:
        self.thread_name = ""
        self.data: dict = {}

    def with_lock(self, fn):
        self.thread_name = threading.current_thread().name
        return fn(self.data)


def test_trade_json_mirror_is_off_event_loop_thread() -> None:
    storage = _Storage()
    service = TradeService(_Repo(), storage)

    asyncio.run(service.append_history({"a_id": "1", "b_id": "2"}))

    assert storage.thread_name != threading.current_thread().name
    assert storage.data["trades"]["history"] == [{"a_id": "1", "b_id": "2"}]


class _Snapshot:
    def __init__(self, data: dict) -> None:
        self.data = data
        self.exists = True

    def to_dict(self) -> dict:
        return dict(self.data)


class _Ref:
    def __init__(self, data: dict, doc_id: str = "") -> None:
        self.data = data
        self.id = doc_id

    def get(self, transaction=None):
        return _Snapshot(self.data)


class _Doc:
    def __init__(self, data: dict, doc_id: str = "") -> None:
        self.reference = _Ref(data, doc_id)


class _Offers:
    def __init__(self, docs: list[_Doc]) -> None:
        self.docs = docs

    def document(self, doc_id: str) -> _Ref:
        for doc in self.docs:
            if doc.reference.id == str(doc_id):
                return doc.reference
        ref = _Ref({}, str(doc_id))
        self.docs.append(_Doc(ref.data, str(doc_id)))
        return ref

    def where(self, **kwargs):
        return self

    def stream(self):
        return iter(self.docs)


class _Transaction:
    def set(self, ref, payload, merge=False) -> None:
        ref.data.update(payload)


class _Db:
    def __init__(self, docs: list[_Doc]) -> None:
        self.offers = _Offers(docs)

    def collection(self, name: str):
        return self.offers

    def transaction(self):
        return _Transaction()


def test_recovery_reopens_only_stale_processing_claims(monkeypatch) -> None:
    now = 100_000
    stale = _Doc({"status": "processing", "processing_started_at": now - 601})
    fresh = _Doc({"status": "processing", "processing_started_at": now - 599})
    legacy = _Doc({"status": "processing"})
    repo = FirestoreTradeRepository(_Db([stale, fresh, legacy]))
    monkeypatch.setattr(firestore_trade_repo.firestore, "transactional", lambda fn: fn)

    repo._sync_recover_stale_processing_offers(now)

    assert stale.reference.data["status"] == "open"
    assert fresh.reference.data["status"] == "processing"
    assert legacy.reference.data["status"] == "processing"


class _RecoveryRepo:
    def __init__(self) -> None:
        self.committed: set[str] | None = None

    async def recover_stale_processing_offers(self, committed: set[str]) -> None:
        self.committed = committed


class _LoadStorage:
    def load(self) -> dict:
        return {"trades": {"offer_transfer_receipts": {"completed-offer": {}}}}


def test_service_passes_committed_receipts_to_stale_recovery() -> None:
    repo = _RecoveryRepo()
    asyncio.run(TradeService(repo, _LoadStorage()).recover_stale_processing_offers())

    assert repo.committed == {"completed-offer"}


def test_recovery_finalizes_a_stale_claim_with_a_committed_transfer(monkeypatch) -> None:
    now = 100_000
    transferred = _Doc({"status": "processing", "processing_started_at": now - 601}, "offer-1")
    repo = FirestoreTradeRepository(_Db([transferred]))
    monkeypatch.setattr(firestore_trade_repo.firestore, "transactional", lambda fn: fn)

    repo._sync_recover_stale_processing_offers(now, {"offer-1"})

    assert transferred.reference.data["status"] == "accepted"


def test_finish_offer_is_idempotent_after_a_lost_success_response(monkeypatch) -> None:
    """A retry must not trigger rollback after Firestore already accepted it."""
    accepted = _Doc({"status": "accepted"}, "offer-1")
    repo = FirestoreTradeRepository(_Db([accepted]))
    monkeypatch.setattr(firestore_trade_repo.firestore, "transactional", lambda fn: fn)

    assert repo._sync_finish_offer("offer-1", "accepted") is True
    assert accepted.reference.data["status"] == "accepted"
