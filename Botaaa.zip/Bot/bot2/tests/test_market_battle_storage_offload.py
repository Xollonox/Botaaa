"""Regression guards for market/battle event-loop storage access."""
from __future__ import annotations

from pathlib import Path


FEATURES = Path(__file__).resolve().parents[1] / "bot" / "features"


def _body(name: str) -> str:
    return (FEATURES / name).read_text(encoding="utf-8")


def test_market_and_battle_use_worker_wrappers_for_sync_storage() -> None:
    for name in ("market.py", "market_views.py", "battle.py", "battle_views.py"):
        body = _body(name)
        # Direct calls are permitted only in the worker wrapper definitions.
        direct_loads = body.count(".storage.load()")
        direct_locks = body.count(".storage.with_lock(")
        if name in {"market.py", "battle.py"}:
            assert "asyncio.to_thread" in body
            assert direct_loads == 0
            assert direct_locks == 0
        else:
            assert direct_loads == 0
            assert direct_locks == 0


def test_friendly_cancel_removes_tasks_using_target_keys() -> None:
    body = _body("battle.py")
    start = body.index("    async def friendly_cancel(")
    end = body.index("    @app_commands.command(name=\"o_battle_unstuck\"", start)
    cancel = body[start:end]
    assert "removed_targets" in cancel
    assert "for tid in removed_targets:" in cancel
    assert "self.friendly_cpu_tasks.pop(tid, None)" in cancel
