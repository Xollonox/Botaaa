"""Regression tests for FirestoreStorage's cross-process CAS contract."""

from __future__ import annotations

from copy import deepcopy

import pytest

from bot.data import firestore_storage
from bot.data.firestore_storage import FirestoreStorage, FirestoreStorageConflict


class _Snapshot:
    def __init__(self, ref: "_Ref") -> None:
        self._ref = ref
        self.id = ref.id
        self.exists = ref.data is not None

    def to_dict(self):
        return dict(self._ref.data) if self._ref.data is not None else None


class _Ref:
    def __init__(self, doc_id: str) -> None:
        self.id = doc_id
        self.data: dict | None = None
        self.collections: dict[str, _Collection] = {}

    def collection(self, name: str) -> "_Collection":
        return self.collections.setdefault(name, _Collection())

    def get(self, transaction=None):
        return _Snapshot(self)

    def set(self, payload, merge=False):
        if merge and self.data is not None:
            self.data.update(payload)
        else:
            self.data = dict(payload)

    def delete(self):
        self.data = None


class _Collection:
    def __init__(self) -> None:
        self.refs: dict[str, _Ref] = {}

    def document(self, doc_id: str) -> _Ref:
        return self.refs.setdefault(str(doc_id), _Ref(str(doc_id)))

    def stream(self):
        return iter([_Snapshot(ref) for ref in self.refs.values() if ref.data is not None])


class _Batch:
    def __init__(self, db: "_Db") -> None:
        self.db = db
        self.ops: list[tuple[str, _Ref, dict | None]] = []

    def set(self, ref: _Ref, payload, merge=False) -> None:
        self.ops.append(("set", ref, dict(payload)))

    def delete(self, ref: _Ref) -> None:
        self.ops.append(("delete", ref, None))

    def commit(self) -> None:
        self.db.batch_sizes.append(len(self.ops))
        for kind, ref, payload in self.ops:
            if kind == "set":
                ref.set(payload)
            else:
                ref.delete()


class _Transaction:
    def set(self, ref: _Ref, payload, merge=False) -> None:
        ref.set(payload, merge=merge)

    def delete(self, ref: _Ref) -> None:
        ref.delete()


class _Db:
    def __init__(self) -> None:
        self.collections: dict[str, _Collection] = {}
        self.batch_sizes: list[int] = []

    def collection(self, name: str) -> _Collection:
        return self.collections.setdefault(name, _Collection())

    def batch(self) -> _Batch:
        return _Batch(self)

    def transaction(self) -> _Transaction:
        return _Transaction()


def test_load_refreshes_and_save_rejects_a_stale_snapshot(monkeypatch) -> None:
    """One worker must not overwrite a newer worker's complete snapshot."""
    monkeypatch.setattr(firestore_storage.firestore, "transactional", lambda fn: fn)
    db = _Db()
    global_ref = db.collection("bot_state").document("global")
    global_ref.set({"marker": "initial", "_bot_storage_version": 0})

    first = FirestoreStorage(db)
    second = FirestoreStorage(db)
    stale_snapshot = first.load()

    second.with_lock(lambda data: data.__setitem__("marker", "newer"))

    # Reads must invalidate the old cache rather than retaining process-local
    # state indefinitely.
    assert first.load()["marker"] == "newer"

    # This snapshot was produced before the other worker's commit. Restore it
    # as first's known cache to model a caller that has not reloaded yet.
    first._cache = deepcopy(stale_snapshot)
    first._version = 0
    stale_snapshot["marker"] = "stale overwrite"
    with pytest.raises(FirestoreStorageConflict):
        first.save(stale_snapshot)

    assert global_ref.data["marker"] == "newer"
    assert global_ref.data["_bot_storage_version"] == 1


def _seed_players(db: _Db, count: int) -> None:
    db.collection("bot_state").document("global").set({"_bot_storage_version": 0})
    players = db.collection("players")
    for i in range(count):
        players.document(str(i)).set({"score": 0})


def test_bulk_player_update_is_chunked_then_published_by_revision(monkeypatch) -> None:
    """More than a transaction's worth of players must never be live-chunked."""
    monkeypatch.setattr(firestore_storage.firestore, "transactional", lambda fn: fn)
    db = _Db()
    _seed_players(db, 400)
    storage = FirestoreStorage(db)

    storage.with_lock(
        lambda state: [player.__setitem__("score", 1) for player in state["players"].values()]
    )

    global_doc = db.collection("bot_state").document("global").data
    revision = global_doc["_bot_players_revision"]
    assert global_doc["_bot_storage_version"] == 1
    assert max(db.batch_sizes) <= 400
    assert len(db.collection("player_revisions").document(revision).collection("players").refs) == 400
    assert all(ref.data["score"] == 0 for ref in db.collection("players").refs.values())
    assert all(player["score"] == 1 for player in storage.load()["players"].values())


def test_stale_bulk_snapshot_cannot_publish_over_a_newer_write(monkeypatch) -> None:
    """A failed bulk CAS leaves its staged copy unreachable from live reads."""
    monkeypatch.setattr(firestore_storage.firestore, "transactional", lambda fn: fn)
    db = _Db()
    _seed_players(db, 400)
    first = FirestoreStorage(db)
    second = FirestoreStorage(db)
    stale = first.load()

    second.with_lock(lambda state: state["players"]["0"].__setitem__("score", 7))
    for player in stale["players"].values():
        player["score"] = 1
    with pytest.raises(FirestoreStorageConflict):
        first.save(stale)

    global_doc = db.collection("bot_state").document("global").data
    assert "_bot_players_revision" not in global_doc
    assert FirestoreStorage(db).load()["players"]["0"]["score"] == 7
