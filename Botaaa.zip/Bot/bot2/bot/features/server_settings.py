"""Server admin settings commands."""

from __future__ import annotations

from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from bot.utils.server_rules import SERVER_SETTINGS_DEFAULTS, get_guild_settings, guild_id_from_interaction, is_admin
from bot.utils.ui import box, e, make_embed
from bot.utils.interaction_visibility import smart_reply


class ServerSettingsCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    def _settings_block(self, data: dict[str, Any], guild_id: int) -> str:
        settings = get_guild_settings(data, guild_id)
        mode = str(settings.get("mode", "all"))
        locked = int(settings.get("locked_channel_id", 0) or 0)
        announce = int(settings.get("announce_channel_id", 0) or 0)
        battle = int(settings.get("battle_channel_id", 0) or 0)
        return box("Server Settings", [
            f"⚙️ Mode: {mode}",
            f"🔒 Locked Channel: {f'<#{locked}>' if locked else 'Not set'}",
            f"📢 Announce Channel: {f'<#{announce}>' if announce else 'Not set'}",
            f"⚔️ Battle Channel: {f'<#{battle}>' if battle else 'Not set'}",
        ])

    async def _require_guild_admin(self, interaction: discord.Interaction, data: dict[str, Any]) -> int | None:
        guild_id = guild_id_from_interaction(interaction)
        if guild_id is None:
            await smart_reply(interaction, "This command can only be used in a server.", ephemeral=True)
            return None
        if not is_admin(interaction):
            await smart_reply(interaction, embed=make_embed(data, f"{e('no', data)} Admin Only", "Not allowed."), ephemeral=True)
            return None
        return guild_id

    @staticmethod
    def _channel_is_in_guild(channel: discord.TextChannel, guild_id: int) -> bool:
        channel_guild = getattr(channel, "guild", None)
        return getattr(channel_guild, "id", None) == guild_id

    def _update_guild_settings(self, guild_id: int, changes: dict[str, Any]) -> None:
        def mutate(data: dict[str, Any]) -> None:
            # Creating this map is the one-way migration boundary: existing
            # legacy settings seed this guild, then other guilds stay default.
            by_guild = data.get("server_settings_by_guild")
            # Read the legacy value before installing the map, because the
            # map's presence intentionally disables legacy fallback.
            inherited = get_guild_settings(data, guild_id)
            if not isinstance(by_guild, dict):
                by_guild = {}
                data["server_settings_by_guild"] = by_guild
            settings = by_guild.get(str(guild_id))
            if not isinstance(settings, dict):
                settings = inherited
                by_guild[str(guild_id)] = settings
            for key, value in SERVER_SETTINGS_DEFAULTS.items():
                settings.setdefault(key, value)
            settings.update(changes)

        self.bot.storage.with_lock(mutate)

    async def _reject_foreign_channel(self, interaction: discord.Interaction) -> None:
        await smart_reply(interaction, "Choose a channel in this server.", ephemeral=True)

    @app_commands.command(name="server_mode", description="Admin: set server mode all/single.")
    @app_commands.describe(mode="Server mode")
    @app_commands.choices(mode=[app_commands.Choice(name="all", value="all"), app_commands.Choice(name="single", value="single")])
    async def server_mode(self, interaction: discord.Interaction, mode: app_commands.Choice[str]) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=False)
        data = self.bot.storage.load()
        guild_id = await self._require_guild_admin(interaction, data)
        if guild_id is None:
            return

        self._update_guild_settings(guild_id, {"mode": str(mode.value)})
        data = self.bot.storage.load()
        settings = get_guild_settings(data, guild_id)
        note = ""
        if str(mode.value) == "single" and int(settings.get("locked_channel_id", 0) or 0) == 0:
            note = f"\n{e('warning', data)} Set locked channel via /server_set_channel"

        await smart_reply(interaction,
            embed=make_embed(data, f"{e('settings', data)} 𝗦𝗘𝗥𝗩𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦", self._settings_block(data, guild_id) + note),
            ephemeral=True,
        )

    @app_commands.command(name="server_set_channel", description="Admin: set locked channel for single mode.")
    async def server_set_channel(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=False)
        data = self.bot.storage.load()
        guild_id = await self._require_guild_admin(interaction, data)
        if guild_id is None:
            return
        if not self._channel_is_in_guild(channel, guild_id):
            await self._reject_foreign_channel(interaction)
            return

        self._update_guild_settings(guild_id, {"locked_channel_id": int(channel.id)})
        data = self.bot.storage.load()
        await smart_reply(interaction,
            embed=make_embed(data, f"{e('settings', data)} 𝗦𝗘𝗥𝗩𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦", self._settings_block(data, guild_id)),
            ephemeral=True,
        )

    @app_commands.command(name="server_set_announce", description="Admin: set announce channel.")
    async def server_set_announce(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=False)
        data = self.bot.storage.load()
        guild_id = await self._require_guild_admin(interaction, data)
        if guild_id is None:
            return
        if not self._channel_is_in_guild(channel, guild_id):
            await self._reject_foreign_channel(interaction)
            return

        self._update_guild_settings(guild_id, {"announce_channel_id": int(channel.id)})
        data = self.bot.storage.load()
        await smart_reply(interaction,
            embed=make_embed(data, f"{e('settings', data)} 𝗦𝗘𝗥𝗩𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦", self._settings_block(data, guild_id)),
            ephemeral=True,
        )

    @app_commands.command(name="server_set_battle", description="Admin: set battle command channel.")
    async def server_set_battle(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=False)
        data = self.bot.storage.load()
        guild_id = await self._require_guild_admin(interaction, data)
        if guild_id is None:
            return
        if not self._channel_is_in_guild(channel, guild_id):
            await self._reject_foreign_channel(interaction)
            return

        self._update_guild_settings(guild_id, {"battle_channel_id": int(channel.id)})
        data = self.bot.storage.load()
        await smart_reply(interaction,
            embed=make_embed(data, f"{e('settings', data)} 𝗦𝗘𝗥𝗩𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦", self._settings_block(data, guild_id)),
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ServerSettingsCog(bot))
