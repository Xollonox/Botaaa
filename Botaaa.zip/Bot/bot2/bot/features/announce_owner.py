"""Owner manual announcement command and event management."""

from __future__ import annotations

import asyncio
import logging

import discord
from discord import app_commands
from discord.ext import commands, tasks
from datetime import datetime
import random

from bot.config import OWNER_GUILD_ID

logger = logging.getLogger(__name__)
from bot.utils.checks import is_owner
from bot.utils.server_rules import (
    get_configured_announcement_channel_ids,
    get_guild_settings,
    guild_id_from_interaction,
)
from bot.utils.ui import e, make_embed
from bot.utils.interaction_visibility import smart_reply
from bot.utils.timeutil import now_ts

OWNER_GUILD = discord.Object(id=OWNER_GUILD_ID)


class AnnounceOwnerCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.card_of_the_day.start()
        self.weekly_bounty.start()

    def cog_unload(self) -> None:
        self.card_of_the_day.cancel()
        self.weekly_bounty.cancel()

    async def _send_to_announcement_channels(
        self, embed: discord.Embed, channel_ids: list[int], event_name: str
    ) -> None:
        for channel_id in channel_ids:
            try:
                channel = self.bot.get_channel(channel_id)
                if channel is None:
                    channel = await self.bot.fetch_channel(channel_id)
                if isinstance(channel, (discord.TextChannel, discord.Thread)):
                    await channel.send(embed=embed)
            except Exception:
                logger.exception("[%s] failed to send announcement to channel %s", event_name, channel_id)

    @tasks.loop(hours=24)
    async def card_of_the_day(self) -> None:
        """Background task: pick and announce Card of the Day every 24 hours."""
        today_str = datetime.utcnow().strftime("%Y-%m-%d")

        def _mutate(data: dict):
            cards = data.get("cards", {})
            if not isinstance(cards, dict) or not cards:
                return None
            card_names = list(cards.keys())
            if not card_names:
                return None
            selected_inner = random.choice(card_names)
            data["cotd"] = {
                "card_name": selected_inner,
                "date": today_str,
                "buff_pct": 15,
            }
            return selected_inner

        selected = await asyncio.to_thread(self.bot.storage.with_lock, _mutate)
        if selected is None:
            return

        # Background tasks have no guild context: announce once to every
        # explicitly configured guild channel, never the old global setting.
        data = self.bot.storage.load_readonly()
        announcement_channel_ids = get_configured_announcement_channel_ids(data)
        if not announcement_channel_ids:
            return

        embed = make_embed(
            data,
            f"⚡ CARD OF THE DAY",
            f"**{selected}** gains **+15% damage** in all battles today!",
        )
        embed.set_footer(text=f"Rotation: {today_str}")
        await self._send_to_announcement_channels(embed, announcement_channel_ids, "CARD_OF_THE_DAY")

    @tasks.loop(hours=168)
    async def weekly_bounty(self) -> None:
        """Background task: pick player with highest win streak and announce bounty every 7 days."""
        def _mutate(data: dict):
            players = data.get("players", {})
            if not isinstance(players, dict):
                return None

            max_streak_inner = 0
            target_id_inner = None
            target_name_inner = "Unknown"

            for uid, player in players.items():
                if not isinstance(player, dict):
                    continue
                ranked_stats = player.get("ranked_stats", {})
                if not isinstance(ranked_stats, dict):
                    continue
                streak = int(ranked_stats.get("streak", 0))
                if streak >= 5 and streak > max_streak_inner:
                    max_streak_inner = streak
                    target_id_inner = str(uid)
                    user = player.get("user", {})
                    target_name_inner = str(user.get("name", "Unknown")) if isinstance(user, dict) else "Unknown"

            if target_id_inner is None or max_streak_inner < 5:
                return None

            week_num = (now_ts() // 604800)
            data["bounty"] = {
                "target_id": target_id_inner,
                "target_name": target_name_inner,
                "streak": max_streak_inner,
                "reward": 3000,
                "week": week_num,
            }

            return target_id_inner, target_name_inner, max_streak_inner

        result = await asyncio.to_thread(self.bot.storage.with_lock, _mutate)
        if result is None:
            return
        target_id, target_name, max_streak = result

        # Re-read snapshot for embed rendering (outside the lock).
        data = self.bot.storage.load_readonly()
        announcement_channel_ids = get_configured_announcement_channel_ids(data)
        if not announcement_channel_ids:
            return

        embed = make_embed(
            data,
            "🎯 WANTED: BOUNTY BOARD",
            f"**@{target_name}** is on a **{max_streak}-win streak**!\n\nFirst to beat them earns **3,000 bonus coins**!",
        )
        embed.set_footer(text="Bounty Board")
        await self._send_to_announcement_channels(embed, announcement_channel_ids, "WEEKLY_BOUNTY")

    @weekly_bounty.before_loop
    async def before_weekly_bounty(self) -> None:
        """Wait for bot to be ready before starting the task."""
        await self.bot.wait_until_ready()

    @card_of_the_day.before_loop
    async def before_card_of_the_day(self) -> None:
        """Wait for bot to be ready before starting the task."""
        await self.bot.wait_until_ready()

    @app_commands.command(name="o_announce", description="Owner: manually post an announcement.")
    @app_commands.guilds(OWNER_GUILD)
    async def o_announce(
        self,
        interaction: discord.Interaction,
        message: str,
        title: str | None = None,
        image_url: str | None = None,
        ping_role: discord.Role | None = None,
    ) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True)
        data = self.bot.storage.load_readonly()
        if not is_owner(interaction):
            await smart_reply(interaction, embed=make_embed(data, f"{e('no', data)} Owner Only", "Not allowed."), ephemeral=True)
            return

        guild_id = guild_id_from_interaction(interaction)
        if guild_id is None:
            await smart_reply(interaction, "This command can only be used in a server.", ephemeral=True)
            return
        settings = get_guild_settings(data, guild_id)
        announce_channel_id = int(settings.get("announce_channel_id", 0) or 0)

        target_channel = interaction.channel
        if announce_channel_id > 0:
            target_channel = self.bot.get_channel(announce_channel_id)
            if target_channel is None:
                try:
                    target_channel = await self.bot.fetch_channel(announce_channel_id)
                except Exception:
                    target_channel = interaction.channel

        if not isinstance(target_channel, (discord.TextChannel, discord.Thread)):
            await smart_reply(interaction,
                embed=make_embed(data, f"{e('warning', data)} Announcement Failed", "Target channel unavailable."),
                ephemeral=True,
            )
            return

        embed = make_embed(
            data,
            f"{e('announce', data)} {title.strip() if isinstance(title, str) and title.strip() else 'Announcement'}",
            str(message),
        )
        embed.set_footer(text="Server Announcement")
        if isinstance(image_url, str) and image_url.strip():
            embed.set_image(url=image_url.strip())

        content = ping_role.mention if ping_role is not None else None
        posted = await target_channel.send(content=content, embed=embed)

        await smart_reply(interaction,
            embed=make_embed(
                data,
                f"{e('ok', data)} Announcement Posted",
                f"{e('channel', data)} {target_channel.mention}\n{e('link', data)} {posted.jump_url}",
            ),
            ephemeral=True,
        )

    @app_commands.command(name="o_event", description="Owner: activate double XP/coins event.")
    @app_commands.guilds(OWNER_GUILD)
    @app_commands.describe(
        event_type="Event type: double_xp or double_coins",
        duration_hours="Duration in hours",
    )
    async def o_event(
        self,
        interaction: discord.Interaction,
        event_type: str = "double_xp",
        duration_hours: int = 24,
    ) -> None:
        """Activate a timed event for double XP or coins."""
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True)
        data = self.bot.storage.load_readonly()
        if not is_owner(interaction):
            await smart_reply(interaction, embed=make_embed(data, f"{e('no', data)} Owner Only", "Not allowed."), ephemeral=True)
            return

        event_type = event_type.lower().strip()
        if event_type not in ("double_xp", "double_coins"):
            await smart_reply(
                interaction,
                embed=make_embed(data, f"{e('no', data)} Invalid Event", "Use: double_xp or double_coins"),
                ephemeral=True,
            )
            return

        duration_hours = max(1, min(720, int(duration_hours)))  # clamp 1-730 hours
        ends_at = now_ts() + (duration_hours * 3600)
        guild_id = guild_id_from_interaction(interaction)
        if guild_id is None:
            await smart_reply(interaction, "This command can only be used in a server.", ephemeral=True)
            return

        def _mutate(data: dict):
            events = data.setdefault("active_events", {})
            if not isinstance(events, dict):
                events = {}
                data["active_events"] = events

            events[event_type] = {
                "active": True,
                "ends_at": ends_at,
            }

            settings = get_guild_settings(data, guild_id)
            return int(settings.get("announce_channel_id", 0) or 0)

        announce_channel_id = await asyncio.to_thread(self.bot.storage.with_lock, _mutate)

        # Re-read snapshot for embed rendering (outside the lock).
        data = self.bot.storage.load_readonly()

        announce_text = "2x XP 🚀" if event_type == "double_xp" else "1.5x CP Rewards 💰"
        embed = make_embed(
            data,
            "🎉 EVENT ACTIVATED",
            f"{announce_text} for **{duration_hours}** hours!",
        )

        if announce_channel_id > 0:
            try:
                channel = self.bot.get_channel(announce_channel_id)
                if channel is None:
                    channel = await self.bot.fetch_channel(announce_channel_id)
                if isinstance(channel, (discord.TextChannel, discord.Thread)):
                    await channel.send(embed=embed)
            except Exception:
                logger.exception(
                    "[EVENT_ANNOUNCE] failed to send event announcement to channel %s",
                    announce_channel_id,
                )

        await smart_reply(
            interaction,
            embed=make_embed(
                data,
                f"{e('ok', data)} Event Started",
                f"{announce_text} for {duration_hours}h",
            ),
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AnnounceOwnerCog(bot))

