"""Onboarding, Terms, and help commands for Lookism Bot v2."""

from __future__ import annotations

from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from bot.utils.checks import effective_owner_ids
from bot.data.defaults import build_default_player
from bot.features.help_index import HELP_CATEGORIES
from bot.utils.timeutil import now_ts
from bot.utils.ui import e, make_embed, skin_embed
from bot.features.packs import grant_newbie_packs
from bot.utils.pack_logic import grant_pending_milestone_packs
from bot.utils.interaction_visibility import smart_reply
from bot.utils.typing_matchup import TYPES, MASTERMIND_BIQ_BONUS, MASTERMIND_IQ_BONUS, relations_table

TERMS_COLOR = 0xE11D48
STARTER_COINS = 1000
STARTER_NEWBIE_PACKS = 3


def has_user_accepted_terms(data: dict[str, Any], user_id: str) -> bool:
    players = data.get("players", {})
    if not isinstance(players, dict):
        return False
    player = players.get(str(user_id))
    if not isinstance(player, dict):
        return False
    user = player.get("user", {})
    if not isinstance(user, dict):
        return False
    return bool(user.get("tos_accepted", False))


def build_terms_embed() -> discord.Embed:
    R = "\u001b[0m"
    RED = "\u001b[1;31m"
    GOLD = "\u001b[1;33m"
    CYAN = "\u001b[1;36m"
    YELLOW = "\u001b[0;33m"
    embed = discord.Embed(
        title="⚠️ LOOKISM CG • Access",
        color=TERMS_COLOR,
        description=(
            "```ansi\n"
            f"{RED}╔═══════════════════════════════════════╗{R}\n"
            f"{RED}║{R}           {GOLD}TERMS OF SERVICE{R}            {RED}║{R}\n"
            f"{RED}╚═══════════════════════════════════════╝{R}\n"
            "\n"
            f"{CYAN}▸ RULES{R}\n"
            "  • Respect all users\n"
            "  • No harassment or hate speech\n"
            "  • Exploiting bugs is prohibited\n"
            "  • Alt-account farming is not allowed\n"
            "\n"
            f"{CYAN}▸ DATA NOTICE{R}\n"
            "  • Player progress is stored securely\n"
            "  • Game economy may change for balance\n"
            "  • Abuse may result in account reset\n"
            "\n"
            f"{CYAN}▸ ACCESS REQUIREMENT{R}\n"
            f"  {YELLOW}Accept these terms before using commands.{R}\n"
            "```"
        ),
    )
    embed.set_footer(text="Terms of Service")
    return embed


def build_start_embed(username: str) -> discord.Embed:
    # ANSI color palette for Discord's ```ansi``` code blocks.
    # Discord ANSI supports: 30 gray, 31 red, 32 green, 33 yellow, 34 blue,
    # 35 pink, 36 cyan, 37 white; style 1 is bold; 0 resets.
    R = "\u001b[0m"           # reset
    RED = "\u001b[1;31m"      # bold red — outer border
    GOLD = "\u001b[1;33m"     # bold gold — title + numeric values
    CYAN = "\u001b[1;36m"     # bold cyan — section headers
    GREEN = "\u001b[0;32m"    # green — slash commands
    embed = discord.Embed(
        title="LOOKISM CG • Account",
        color=TERMS_COLOR,
        description=(
            f"Welcome, {username}\n"
            "```ansi\n"
            f"{RED}╔═══════════════════════════════════════╗{R}\n"
            f"{RED}║{R}          {GOLD}ACCOUNT INITIALIZED{R}          {RED}║{R}\n"
            f"{RED}╚═══════════════════════════════════════╝{R}\n"
            "\n"
            f"{CYAN}▸ STARTER PACKAGE{R}\n"
            f"  Coins ................... {GOLD}{STARTER_COINS:,}{R}\n"
            f"  Gems ........................ {GOLD}0{R}\n"
            f"  Packs ....................... {GOLD}{STARTER_NEWBIE_PACKS}{R}\n"
            "\n"
            f"{CYAN}▸ YOUR JOURNEY{R}\n"
            "  • Collect powerful fighters\n"
            "  • Build squads for battle\n"
            "  • Battle opponents in leagues\n"
            "  • Climb the ranks\n"
            "\n"
            f"{CYAN}▸ BEGIN{R}\n"
            f"  {GREEN}/help{R}    {GREEN}/tutorial{R}    {GREEN}/shop{R}\n"
            f"  {GREEN}/squad{R}   {GREEN}/battle{R}\n"
            "```"
        ),
    )
    embed.set_footer(text="Account Registration")
    return embed


def build_about_embed() -> discord.Embed:
    R = "\u001b[0m"
    RED = "\u001b[1;31m"
    GOLD = "\u001b[1;33m"
    CYAN = "\u001b[1;36m"
    GREEN = "\u001b[0;32m"
    embed = discord.Embed(
        color=TERMS_COLOR,
        description=(
            "```ansi\n"
            f"{RED}╔═══════════════════════════════════════╗{R}\n"
            f"{RED}║{R}            {GOLD}SYSTEM OVERVIEW{R}            {RED}║{R}\n"
            f"{RED}╚═══════════════════════════════════════╝{R}\n"
            "\n"
            f"{CYAN}▸ COMBAT{R}\n"
            "  • Ranked squad battles\n"
            "  • Competitive leagues\n"
            "  • PvP progression\n"
            "\n"
            f"{CYAN}▸ CARDS{R}\n"
            "  • Collect powerful fighters\n"
            "  • Upgrade star levels\n"
            "  • Build squads for battle\n"
            "\n"
            f"{CYAN}▸ ECONOMY{R}\n"
            "  • Player market trading\n"
            "  • Store and pack rolls\n"
            "  • Hourly / daily / weekly rewards\n"
            "\n"
            f"{CYAN}▸ SOCIAL{R}\n"
            "  • Create or join gangs\n"
            "  • Seasonal milestones\n"
            "  • Achievements and leaderboards\n"
            "\n"
            f"{CYAN}▸ QUICK START{R}\n"
            f"  {GREEN}/start{R}    {GREEN}/help{R}    {GREEN}/tutorial{R}\n"
            f"  {GREEN}/shop{R}     {GREEN}/squad{R}   {GREEN}/battle{R}\n"
            "```"
        ),
    )
    embed.set_footer(text="System Info")
    return embed


def _pack_count(player: dict[str, Any], pack_key: str) -> int:
    packs = player.get("pack_inventory")
    if isinstance(packs, dict):
        return int(packs.get(pack_key, 0))
    user = player.get("user", {})
    inv = user.get("pack_inventory", []) if isinstance(user, dict) else []
    if isinstance(inv, list):
        total = 0
        for item in inv:
            if isinstance(item, dict) and str(item.get("key", "")) == pack_key:
                total += int(item.get("quantity", item.get("qty", 1)))
        return total
    return 0


def _starter_already_granted(player: dict[str, Any]) -> bool:
    user = player.get("user", {})
    if not isinstance(user, dict):
        return False
    if bool(user.get("starter_granted", False)):
        return True
    has_progress = (
        int(user.get("balance", user.get("coins", 0)) or 0) > 0
        or bool(user.get("inventory"))
        or _pack_count(player, "newbie_pack") > 0
    )
    return has_progress


def ensure_started_player(
    data: dict[str, Any],
    user_id: str,
    username: str,
    *,
    accept_terms: bool,
) -> tuple[dict[str, Any], bool]:
    players = data.setdefault("players", {})
    player = players.get(user_id)
    if not isinstance(player, dict):
        player = build_default_player(user_id, username, now_ts())
        players[user_id] = player

    user = player.get("user")
    if not isinstance(user, dict):
        user = {}
        player["user"] = user

    user["id"] = user_id
    user["name"] = username
    if accept_terms:
        user["tos_accepted"] = True

    # Account creation and consent are separate.  Do not create starter value
    # until the user has explicitly accepted through the TermsGateView.
    granted = False
    if bool(user.get("tos_accepted", False)) and not _starter_already_granted(player):
        user["balance"] = max(int(user.get("balance", user.get("coins", 0)) or 0), STARTER_COINS)
        user["premium_balance"] = max(int(user.get("premium_balance", 0) or 0), 0)
        grant_newbie_packs(data, user_id)
        user["starter_granted"] = True
        granted = True
    return player, granted


class TermsGateView(discord.ui.View):
    def __init__(self, bot: commands.Bot, user_id: int) -> None:
        super().__init__(timeout=180)
        self.bot = bot
        self.user_id = int(user_id)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return int(interaction.user.id) == self.user_id

    @discord.ui.button(label="Accept Terms", style=discord.ButtonStyle.success, row=0)
    async def accept_terms(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=False)
        user_id = str(interaction.user.id)
        username = interaction.user.name

        def mutate(data: dict[str, Any]) -> dict[str, Any]:
            ensure_started_player(data, user_id, username, accept_terms=True)
            return data

        self.bot.storage.with_lock(mutate)
        # Warm the bot-level terms cache so subsequent commands skip storage.load()
        if hasattr(self.bot, "mark_terms_accepted"):
            self.bot.mark_terms_accepted(interaction.user.id)
        if interaction.response.is_done():
            await interaction.followup.send("Terms accepted successfully.")
        else:
            await interaction.followup.send("Terms accepted successfully.")

    @discord.ui.button(label="Start", style=discord.ButtonStyle.primary, row=0)
    async def start_panel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        data = self.bot.storage.load_readonly()
        if not has_user_accepted_terms(data, str(interaction.user.id)):
            if interaction.response.is_done():
                await interaction.followup.send("You must accept the terms first.")
            else:
                await interaction.response.send_message("You must accept the terms first.")
            return

        embed = build_start_embed(interaction.user.mention)
        view = StartQuickLinksView(self.bot)
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, view=view)
        else:
            await interaction.response.send_message(embed=embed, view=view)




class StartQuickLinksView(discord.ui.View):
    def __init__(self, bot: commands.Bot) -> None:
        super().__init__(timeout=180)
        self.bot = bot

    @discord.ui.button(label="📜 Terms", style=discord.ButtonStyle.secondary, row=0)
    async def terms_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        embed = build_terms_embed()
        view = TermsGateView(self.bot, interaction.user.id)
        await smart_reply(interaction, embed=embed, view=view)

    @discord.ui.button(label="📘 About", style=discord.ButtonStyle.primary, row=0)
    async def about_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        embed = build_about_embed()
        await smart_reply(interaction, embed=embed)


def _is_owner_category(category: dict[str, Any]) -> bool:
    name = str(category.get("name", "")).lower()
    if "owner" in name or "admin" in name:
        return True
    items = category.get("items", [])
    if isinstance(items, list):
        for cmd, _ in items:
            if str(cmd).strip().startswith("/o_"):
                return True
    return False


def _pipeline_embed() -> discord.Embed:
    body = (
        "**Damage is computed in this order:**\n"
        "```\n"
        "1. Miss check          : if attacker.biq < defender.biq, roll for miss\n"
        "2. Base roll           : strength/2 ± range by move type\n"
        "                         normal ±5 | special +20..+45\n"
        "                         unique_skill 3x..4x | path +40..+80\n"
        "3. Strength bonus      : +10/+15/+30 if Strength mastery (by move)\n"
        "4. Technique multiplier: 1.04..1.30 (higher moves = bigger boost)\n"
        "5. Attacker IQ scaling : × (1 + iq/500)\n"
        "6. Defender IQ scaling : × (1 − iq/500)\n"
        "7. Typing multiplier   : × Π(attacker_type → defender_type)\n"
        "8. Defensive typing    : × Tank/Fighter/Brawler incoming reductions\n"
        "9. Defense reaction    : Block / Dodge / Parry / Revert / Tank-DR\n"
        "```\n"
        f"**Mastermind passive** (per card): +{MASTERMIND_IQ_BONUS} effective IQ "
        f"and +{MASTERMIND_BIQ_BONUS} effective BIQ while active.\n"
    )
    return make_embed(None, "LOOKISM CG • STATS GUIDE", body, color=0xE11D48, footer="How damage works")


def _typing_embed() -> discord.Embed:
    lines = ["**Character Typings:** " + " / ".join(TYPES), "", "**Matchup chart:**", "```"]
    lines.append(f"{'Attacker':<11} → {'Defender':<11}  out   in")
    for at, dt, off, dfn in relations_table():
        lines.append(f"{at:<11} → {dt:<11}  ×{off:<4} ×{dfn:<4}")
    lines.append("```")
    lines.append(
        "**Rules for 2-type cards:**\n"
        "• For each pair (attacker_type × defender_type), the matching factor multiplies in.\n"
        "• If both cards share the same two types, all effects nullify (×1.00).\n"
        "• Mastermind has no matchup relations — its bonus is a passive IQ/BIQ boost."
    )
    return make_embed(None, "LOOKISM CG • TYPING CHART", "\n".join(lines), color=0xE11D48, footer="Counter-play")


class HelpPaginatorView(discord.ui.View):
    def __init__(self, invoker_id: int, data: dict[str, Any], *, timeout: float = 120) -> None:
        super().__init__(timeout=timeout)
        self.invoker_id = invoker_id
        self.data = data
        self.page = 0
        is_owner_user = int(invoker_id) in effective_owner_ids()
        self.categories = [c for c in HELP_CATEGORIES if is_owner_user or not _is_owner_category(c)]
        self.total = len(self.categories)
        self.message: discord.Message | None = None
        self._refresh_buttons()
        self.category_select.options = [
            discord.SelectOption(label=str(cat.get("name", "Category"))[:100], value=str(i))
            for i, cat in enumerate(self.categories[:25])
        ]
        self.category_select.placeholder = "Jump to category"

    def _refresh_buttons(self) -> None:
        at_start = self.page <= 0
        at_end = self.page >= self.total - 1
        self.prev_button.disabled = at_start
        self.next_button.disabled = at_end
        self.home_button.disabled = at_start

    def _chunk_lines(self, lines: list[str], limit: int = 1000) -> list[str]:
        chunks: list[str] = []
        current = ""
        for line in lines:
            candidate = f"{current}\n{line}" if current else line
            if len(candidate) > limit:
                if current:
                    chunks.append(current)
                current = line
            else:
                current = candidate
        if current:
            chunks.append(current)
        return chunks or [f"{e('dot', self.data)} No commands in this category yet."]

    def _build_embed(self) -> discord.Embed:
        cat = self.categories[self.page]
        cat_emoji = e(cat.get("emoji_key", "info"), self.data)
        sep = e("line", self.data)
        dot = e("dot", self.data)
        box = e("box", self.data)

        title = f"{e('help', self.data)}  Help Hub  \u2022  {cat['name']}"

        description = (
            f"{sep * 3}\n"
            f"{cat_emoji}  **{cat['name']}**  \u2014  Page `{self.page + 1}` of `{self.total}`\n"
            f"{sep * 3}"
        )

        lines = [f"{dot} `{cmd}` \u2014 {desc}" for cmd, desc in cat["items"]]
        chunks = self._chunk_lines(lines)

        fields: list[tuple[str, str, bool]] = []
        for idx, chunk in enumerate(chunks[:3], start=1):
            label = f"{box} Commands" if len(chunks) == 1 else f"{box} Commands  ({idx})"
            fields.append((label, chunk, False))

        embed = make_embed(self.data, title, description, variant="premium", fields=fields)
        return skin_embed(embed, data=self.data)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.invoker_id:
            await smart_reply(
                interaction,
                embed=make_embed(
                    self.data,
                    f"{e('warning', self.data)}  Access Locked",
                    (
                        f"{e('line', self.data)}\n"
                        f"{e('box', self.data)}  This menu belongs to another user.\n"
                        f"{e('dot', self.data)}  Use `/help` to open your own panel."
                    ),
                ),
                ephemeral=True,
            )
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass

    @discord.ui.button(label="\u25c4  Prev", style=discord.ButtonStyle.secondary, row=0)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page -= 1
        self._refresh_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="\u2302 Home", style=discord.ButtonStyle.secondary, row=0)
    async def home_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page = 0
        self._refresh_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="Next  \u25ba", style=discord.ButtonStyle.primary, row=0)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page += 1
        self._refresh_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)


    @discord.ui.select(placeholder="Jump to category", min_values=1, max_values=1, options=[discord.SelectOption(label="Loading...", value="0")], row=1)
    async def category_select(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        try:
            self.page = max(0, min(int(select.values[0]), self.total - 1))
        except Exception:
            self.page = 0
        self._refresh_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="⚔️ Battle Guide", style=discord.ButtonStyle.secondary, row=2)
    async def battle_guide_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        class _GuideView(discord.ui.View):
            def __init__(self) -> None:
                super().__init__(timeout=120)

            @discord.ui.button(label="Pipeline", style=discord.ButtonStyle.secondary)
            async def go_pipeline(self, i: discord.Interaction, _: discord.ui.Button) -> None:
                await i.response.edit_message(embed=_pipeline_embed(), view=self)

            @discord.ui.button(label="Typing chart", style=discord.ButtonStyle.secondary)
            async def go_typing(self, i: discord.Interaction, _: discord.ui.Button) -> None:
                await i.response.edit_message(embed=_typing_embed(), view=self)

        await interaction.response.send_message(embed=_pipeline_embed(), view=_GuideView(), ephemeral=True)


class OnboardingCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="start", description="Open your account panel.")
    async def start(self, interaction: discord.Interaction) -> None:
        user_id = str(interaction.user.id)
        username = interaction.user.name

        # Defer before any storage work: the mutation performs a Firestore
        # fetch + transactional commit, which on a slow connection burns
        # Discord's 3s ack window (error 10062) before this reply could send.
        await interaction.response.defer()

        def mutate(data: dict[str, Any]) -> dict[str, Any]:
            # /start must never act as consent.  The TermsGateView is the
            # only path that passes accept_terms=True.
            ensure_started_player(data, user_id, username, accept_terms=False)
            # Grant any pending milestone packs queued from level-ups
            grant_pending_milestone_packs(data, user_id)
            return data

        await self.bot.storage.async_with_lock(mutate)

        embed = build_start_embed(interaction.user.mention)
        view = StartQuickLinksView(self.bot)
        await interaction.followup.send(embed=embed, view=view)


    @app_commands.command(name="help", description="Browse all commands by category.")
    async def help(self, interaction: discord.Interaction) -> None:
        data = self.bot.storage.load_readonly()
        view = HelpPaginatorView(interaction.user.id, data, timeout=120)
        await smart_reply(interaction, embed=view._build_embed(), view=view, ephemeral=True)
        view.message = await interaction.original_response()


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(OnboardingCog(bot))
