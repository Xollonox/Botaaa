"""Logging configuration for Lookism Bot."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_MAX_BYTES = 10 * 1024 * 1024
LOG_BACKUP_COUNT = 5


def setup_logging(log_dir: Path | None = None) -> None:
    """Configure idempotent console and bounded file logging for the process."""
    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    configured = {getattr(handler, "_botaaa_handler", None) for handler in root.handlers}
    if "stream" not in configured:
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(fmt)
        stream_handler._botaaa_handler = "stream"  # type: ignore[attr-defined]
        root.addHandler(stream_handler)

    if "file" not in configured:
        log_dir = log_dir or Path(__file__).resolve().parents[2] / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_dir / "bot.log",
            maxBytes=LOG_MAX_BYTES,
            backupCount=LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
        file_handler.setFormatter(fmt)
        file_handler._botaaa_handler = "file"  # type: ignore[attr-defined]
        root.addHandler(file_handler)

    root.setLevel(logging.INFO)
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("discord.http").setLevel(logging.WARNING)
