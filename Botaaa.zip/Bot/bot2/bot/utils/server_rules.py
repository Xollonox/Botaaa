"""Server-level rule enforcement helpers."""

from __future__ import annotations

from typing import Any

import discord

SERVER_SETTINGS_DEFAULTS = {
    "mode": "all",
    "locked_channel_id": 0,
    "announce_channel_id": 0,
    "battle_channel_id": 0,
}


def guild_id_from_interaction(interaction: discord.Interaction) -> int | None:
    """Return a guild ID only for a real guild interaction."""
    guild_id = getattr(interaction, "guild_id", None)
    try:
        return int(guild_id) if guild_id is not None else None
    except (TypeError, ValueError):
        return None


def get_guild_settings(data: dict[str, Any], guild_id: int | None) -> dict[str, Any]:
    """Get settings for one guild without allowing settings to leak to another.

    ``server_settings`` was the pre-guild legacy shape.  It remains a read
    fallback only until the first guild-scoped setting is saved.  That keeps
    existing deployments working while a subsequent admin update migrates to
    ``server_settings_by_guild``; once it contains a guild entry,
    unconfigured guilds use safe defaults rather than another guild's settings.
    """
    settings = dict(SERVER_SETTINGS_DEFAULTS)
    if guild_id is None:
        return settings

    by_guild = data.get("server_settings_by_guild")
    if isinstance(by_guild, dict) and by_guild:
        stored = by_guild.get(str(guild_id))
        if isinstance(stored, dict):
            settings.update(stored)
        return settings

    # Compatibility for data saved before settings were guild-scoped. An empty
    # mapping is also a pre-migration marker installed by ensure_structure().
    legacy = data.get("server_settings")
    if isinstance(legacy, dict):
        settings.update(legacy)
    return settings


def get_configured_announcement_channel_ids(data: dict[str, Any]) -> list[int]:
    """Return unique announcement channels from guild-scoped settings only.

    Background announcements have no invoking guild, so consulting the legacy
    global setting would route a message to an arbitrary server. Legacy data is
    used only by an interactive admin update, which seeds its guild entry.
    """
    by_guild = data.get("server_settings_by_guild")
    if not isinstance(by_guild, dict):
        return []
    channel_ids: list[int] = []
    for settings in by_guild.values():
        if not isinstance(settings, dict):
            continue
        try:
            channel_id = int(settings.get("announce_channel_id", 0) or 0)
        except (TypeError, ValueError):
            continue
        if channel_id > 0 and channel_id not in channel_ids:
            channel_ids.append(channel_id)
    return channel_ids


def is_admin(interaction: discord.Interaction) -> bool:
    """Return True only for an owner/admin acting inside a guild."""
    if guild_id_from_interaction(interaction) is None:
        return False
    from bot.utils.checks import is_owner

    if is_owner(interaction):
        return True
    member = interaction.user
    if hasattr(member, "guild_permissions"):
        return bool(member.guild_permissions.administrator)  # type: ignore[union-attr]
    return False


def check_single_mode_allowed(
    interaction: discord.Interaction,
) -> tuple[bool, str, int]:
    """Check whether a command is allowed by this guild's channel mode."""
    bot = interaction.client
    storage = getattr(bot, "storage", None)
    if storage is None:
        return True, "all", 0

    settings = get_guild_settings(storage.load_readonly(), guild_id_from_interaction(interaction))
    mode = str(settings.get("mode", "all"))
    if mode != "single":
        return True, mode, 0

    locked_id = int(settings.get("locked_channel_id", 0) or 0)
    if locked_id == 0:
        return True, mode, 0

    channel_id = interaction.channel_id or 0
    if int(channel_id) == locked_id:
        return True, mode, locked_id

    return False, mode, locked_id


def check_battle_channel_allowed(
    interaction: discord.Interaction,
) -> tuple[bool, str | None, int | None]:
    """Check whether a battle command is allowed in this guild's channel."""
    bot = interaction.client
    storage = getattr(bot, "storage", None)
    if storage is None:
        return True, None, None

    settings = get_guild_settings(storage.load_readonly(), guild_id_from_interaction(interaction))
    battle_id = int(settings.get("battle_channel_id", 0) or 0)
    if battle_id == 0:
        return True, None, None

    channel_id = int(interaction.channel_id or 0)
    if channel_id == battle_id:
        return True, None, battle_id
    return False, "not_allowed", battle_id
