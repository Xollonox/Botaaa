"""Firestore-backed storage with the old JSON ``Storage`` public API
(``load``, ``load_readonly``, ``with_lock``, ``save``, ``async_save``).

Data is split between a ``players`` collection (one doc per user id, to
stay under Firestore's 1MB/doc limit) and a ``bot_state/global`` doc for
everything else. ``with_lock``/``save`` are synchronous blocking network
calls; the ~60+ call sites rely on that contract (none ``await`` them).
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from copy import deepcopy
from typing import Any, Callable, TypeVar
from uuid import uuid4

from google.cloud import firestore
from google.cloud.firestore_v1 import Client

from .defaults import build_default_data, ensure_structure

T = TypeVar("T")
logger = logging.getLogger(__name__)

PLAYERS_COLLECTION = "players"
PLAYER_REVISIONS_COLLECTION = "player_revisions"
GLOBAL_COLLECTION = "bot_state"
GLOBAL_DOC_ID = "global"

# Firestore batched writes are capped at 500 operations.
_BATCH_LIMIT = 400
# A version on the global document is the cross-process write coordinator.
# Keep this private field out of the JSON-compatible public data structure.
_STORAGE_VERSION = "_bot_storage_version"
_PLAYERS_REVISION = "_bot_players_revision"
_MAX_WRITE_RETRIES = 3


class FirestoreStorageConflict(RuntimeError):
    """A concurrent writer prevented an atomic storage update."""


def _storage_version(value: Any) -> int:
    """Coerce legacy version values without allowing negative versions."""
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _sanitize_for_firestore(value: Any, path: str = "root") -> Any:
    if isinstance(value, dict):
        return {str(k): _sanitize_for_firestore(v, f"{path}.{k}") for k, v in value.items()}
    if isinstance(value, list):
        return [_sanitize_for_firestore(v, f"{path}[{i}]") for i, v in enumerate(value)]
    if isinstance(value, tuple):
        logger.warning("[FIRESTORE_SANITIZE] Converted tuple at path %s to list (len=%s)", path, len(value))
        return [_sanitize_for_firestore(v, f"{path}[{i}]") for i, v in enumerate(value)]
    if isinstance(value, set):
        sample = next(iter(value), None)
        logger.warning("[FIRESTORE_SANITIZE] Converted set at path %s to list (len=%s sample=%r)", path, len(value), sample)
        # Preserve element types ({100, 200} -> [100, 200], not ["100", "200"]).
        # Sorting is only for deterministic output; key= handles mixed types.
        normalized = sorted(value, key=lambda x: str(x))
        return [_sanitize_for_firestore(v, f"{path}[{i}]") for i, v in enumerate(normalized)]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    logger.warning("[FIRESTORE_SANITIZE] Converted unsupported type at path %s type=%s to str", path, type(value).__name__)
    return str(value)


# Read-only gates (registration, ban, wrong-channel) run on every
# interaction; a short TTL keeps them off Firestore while bounding staleness.
_READONLY_CACHE_TTL_SECONDS = 3.0

# How fresh the working cache may be for ``with_lock`` to reuse it instead of
# paying a full players-collection scan before committing. The CAS version
# check in ``_commit_diff`` still detects any cross-process write, and the
# retry loop fetches a fresh snapshot after the first conflict.
_WRITE_FRESHNESS_SECONDS = 2.0


class FirestoreStorage:
    """Thread-safe Firestore-backed storage matching ``Storage``'s public API."""

    def __init__(self, client: Client) -> None:
        self._db = client
        self.lock = threading.Lock()
        self._cache: dict[str, Any] | None = None
        self._readonly_cache: dict[str, Any] | None = None
        self._readonly_ts: float = 0.0
        self._readonly_refresh_active = False
        self._cache_ts: float = 0.0
        self._version = 0
        # ``None`` denotes the legacy top-level players collection.
        self._players_revision: str | None = None

    # ------------------------------------------------------------------
    # Fetch helpers
    # ------------------------------------------------------------------

    def _fetch_global(self) -> dict[str, Any]:
        doc = self._db.collection(GLOBAL_COLLECTION).document(GLOBAL_DOC_ID).get()
        data = doc.to_dict()
        if not isinstance(data, dict):
            self._version = 0
            self._players_revision = None
            return {}
        # Old deployments have no marker; treating them as version zero makes
        # the first transactional write upgrade them without migration. Never
        # let a malformed manually-edited marker take the bot offline.
        data = dict(data)
        raw_version = data.pop(_STORAGE_VERSION, 0)
        raw_players_revision = data.pop(_PLAYERS_REVISION, None)
        self._players_revision = str(raw_players_revision) if raw_players_revision else None
        self._version = _storage_version(raw_version)
        if self._version == 0 and raw_version not in (0, "0", None):
            logger.warning("[FIRESTORE_STORAGE] Invalid storage version %r; treating it as 0", raw_version)
        return data

    def _players_collection(self, revision: str | None = None) -> Any:
        """Return the collection selected by the global revision pointer."""
        revision = self._players_revision if revision is None else revision
        if revision is None:
            return self._db.collection(PLAYERS_COLLECTION)
        return self._db.collection(PLAYER_REVISIONS_COLLECTION).document(revision).collection(PLAYERS_COLLECTION)

    def _fetch_players(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for doc in self._players_collection().stream():
            data = doc.to_dict()
            if isinstance(data, dict):
                out[doc.id] = data
        return out

    def _load_from_firestore(self) -> dict[str, Any]:
        global_data = self._fetch_global()
        players = self._fetch_players()
        if not global_data and not players:
            data = build_default_data()
            self._write_full(data)
            return data
        combined = {**global_data, "players": players}
        return ensure_structure(combined)

    def _live_data(self) -> dict[str, Any]:
        if self._cache is None:
            self._cache = self._load_from_firestore()
            self._cache_ts = time.monotonic()
        return self._cache

    # ------------------------------------------------------------------
    # Public API (mirrors bot.data.storage.Storage)
    # ------------------------------------------------------------------

    def load(self) -> dict[str, Any]:
        """Return a current, isolated snapshot.

        A process-local cache cannot be used as a source of truth when several
        bot workers share Firestore. Refreshing here also invalidates stale
        data left by a failed/aborted write.
        """
        with self.lock:
            self._cache = self._load_from_firestore()
            self._cache_ts = time.monotonic()
            return deepcopy(self._cache)

    def load_readonly(self) -> dict[str, Any]:
        """Return the current cached snapshot for read-only legacy callers.

        The returned object remains a compatibility API, so callers must not
        mutate it. Writers must use :meth:`with_lock` or :meth:`save`.

        Hits are served from a short-TTL in-memory cache. Expired snapshots
        are served stale-while-revalidate: a background thread refetches
        while the caller gets the last good snapshot immediately. Read-only
        gates run on every interaction inside Discord's 3s ack window, so
        they must never pay a synchronous full Firestore scan. Writes
        (``with_lock``/``save``) refresh the cache immediately, so a
        just-registered or just-updated user never waits out the TTL. The
        returned snapshot is a deepcopy so a caller accidentally mutating it
        cannot corrupt the shared cache.
        """
        with self.lock:
            now = time.monotonic()
            if self._readonly_cache is not None:
                if now - self._readonly_ts < _READONLY_CACHE_TTL_SECONDS:
                    return deepcopy(self._readonly_cache)
                # Stale: serve it now, refresh in the background.
                self._start_readonly_refresh_locked()
                return deepcopy(self._readonly_cache)
            # Cold path (pre-boot warm): no snapshot exists yet, so there is
            # nothing stale to serve. Block on the first fetch only.
            if self._cache is None:
                self._cache = self._load_from_firestore()
                self._cache_ts = now
            self._readonly_cache = self._cache
            self._readonly_ts = now
            return deepcopy(self._readonly_cache)

    def _start_readonly_refresh_locked(self) -> None:
        """Kick off a background snapshot refresh. Caller must hold ``self.lock``."""
        if self._readonly_refresh_active:
            return
        self._readonly_refresh_active = True
        thread = threading.Thread(
            target=self._refresh_readonly_cache,
            name="firestore-readonly-refresh",
            daemon=True,
        )
        thread.start()

    def _refresh_readonly_cache(self) -> None:
        try:
            snapshot = self._load_from_firestore()
        except Exception:
            # Keep serving the previous snapshot; the next expired call retries.
            logger.warning(
                "[FIRESTORE_STORAGE] Background readonly refresh failed",
                exc_info=True,
            )
        else:
            with self.lock:
                self._cache = snapshot
                self._cache_ts = time.monotonic()
                self._readonly_cache = snapshot
                self._readonly_ts = time.monotonic()
        finally:
            with self.lock:
                self._readonly_refresh_active = False

    def _write_full(self, data: dict[str, Any]) -> None:
        """Full replace: used only for first-time seeding of an empty database."""
        sanitized = _sanitize_for_firestore(data)
        players = sanitized.pop("players", {}) if isinstance(sanitized.get("players"), dict) else {}
        sanitized[_STORAGE_VERSION] = 0
        sanitized.pop(_PLAYERS_REVISION, None)
        self._db.collection(GLOBAL_COLLECTION).document(GLOBAL_DOC_ID).set(sanitized)
        items = list(players.items())
        coll = self._db.collection(PLAYERS_COLLECTION)
        for i in range(0, len(items), _BATCH_LIMIT):
            batch = self._db.batch()
            for uid, pdata in items[i : i + _BATCH_LIMIT]:
                batch.set(coll.document(str(uid)), pdata)
            batch.commit()

    def _commit_diff(self, data: dict[str, Any], before: dict[str, Any], *, expected_version: int | None = None) -> None:
        """Write a diff with a CAS-protected player revision switch.

        Small updates retain the usual single Firestore transaction. A
        transaction cannot contain more than 500 writes, so a large update is
        copied into an unreferenced revision in batches. Only after all copies
        succeed does a one-write CAS transaction publish that revision. A
        concurrent writer therefore either precedes the switch or makes it
        fail; it can never observe or overwrite a partial bulk write.
        """
        sanitized = _sanitize_for_firestore(data)
        players = sanitized.get("players", {}) if isinstance(sanitized.get("players"), dict) else {}
        rest = {
            k: v
            for k, v in sanitized.items()
            if k not in {"players", _STORAGE_VERSION, _PLAYERS_REVISION}
        }
        previous_players_revision = self._players_revision

        before_players = before.get("players", {}) if isinstance(before.get("players"), dict) else {}
        before_rest = {
            k: v
            for k, v in before.items()
            if k not in {"players", _STORAGE_VERSION, _PLAYERS_REVISION}
        }
        coll = self._players_collection()
        ops: list[tuple[str, str, Any]] = []
        for uid, pdata in players.items():
            if pdata != before_players.get(uid):
                ops.append(("set", str(uid), pdata))
        for uid in before_players.keys() - players.keys():
            ops.append(("delete", str(uid), None))

        rest_changed = rest != before_rest
        if not ops and not rest_changed:
            return

        version = self._version if expected_version is None else expected_version
        next_players_revision = self._players_revision

        # Never chunk writes to the live collection: another process could
        # commit between chunks. Stage the *complete* snapshot instead. Failed
        # or stale attempts leave only an unreachable revision, which is safe.
        staged = len(ops) + 1 > _BATCH_LIMIT
        if staged:
            next_players_revision = uuid4().hex
            staged_coll = self._players_collection(next_players_revision)
            staged_items = list(players.items())
            for i in range(0, len(staged_items), _BATCH_LIMIT):
                batch = self._db.batch()
                for uid, pdata in staged_items[i : i + _BATCH_LIMIT]:
                    batch.set(staged_coll.document(str(uid)), pdata)
                batch.commit()

        global_ref = self._db.collection(GLOBAL_COLLECTION).document(GLOBAL_DOC_ID)
        current_players_revision = self._players_revision

        @firestore.transactional
        def txn(transaction: firestore.Transaction) -> None:
            current = global_ref.get(transaction=transaction)
            current_data = current.to_dict() if current.exists else {}
            current_version = _storage_version((current_data or {}).get(_STORAGE_VERSION, 0))
            if current_version != version:
                raise FirestoreStorageConflict("Storage changed in another process")
            if next_players_revision == current_players_revision:
                for kind, uid, payload in ops:
                    if kind == "set":
                        transaction.set(coll.document(uid), payload)
                    else:
                        transaction.delete(coll.document(uid))
            global_payload = {**rest, _STORAGE_VERSION: version + 1}
            if next_players_revision is not None:
                global_payload[_PLAYERS_REVISION] = next_players_revision
            transaction.set(global_ref, global_payload)

        published = False
        try:
            txn(self._db.transaction())
            published = True
        finally:
            if staged:
                # Reclaim orphaned revision data: the freshly written snapshot
                # if the publish failed, or the superseded revision it
                # replaced once the pointer has moved on. Both are
                # unreachable after this point; deletion is best-effort.
                revision_to_clear = (
                    previous_players_revision if published else next_players_revision
                )
                if revision_to_clear is not None:
                    self._delete_revision_collection(revision_to_clear)
        self._version = version + 1
        self._players_revision = next_players_revision

    def _delete_revision_collection(self, revision: str) -> None:
        """Best-effort recursive delete of an orphaned players revision."""
        try:
            ref = self._db.collection(PLAYER_REVISIONS_COLLECTION).document(revision)
            self._db.recursive_delete(ref)
        except Exception:
            logger.warning(
                "[FIRESTORE_STORAGE] Failed to delete player revision %s",
                revision,
                exc_info=True,
            )

    def save(self, data: dict[str, Any]) -> None:
        """Persist a snapshot using compare-and-swap, never a stale overwrite.

        Unlike ``with_lock``, an arbitrary snapshot cannot safely be replayed:
        its caller may have made decisions from old state. A version conflict
        therefore raises :class:`FirestoreStorageConflict` for the caller to
        reload and retry deliberately.
        """
        with self.lock:
            before = self._cache if self._cache is not None else self._load_from_firestore()
            version = self._version
            self._commit_diff(data, before, expected_version=version)
            # Keep a private copy: callers commonly retain and mutate ``data``.
            self._cache = deepcopy(data)
            self._cache.pop(_STORAGE_VERSION, None)
            self._cache.pop(_PLAYERS_REVISION, None)
            self._cache_ts = time.monotonic()
            # The committed snapshot is the freshest state this process has;
            # serve read-only gates from it within the TTL window.
            self._readonly_cache = deepcopy(self._cache)
            self._readonly_ts = time.monotonic()

    async def async_load(self) -> dict[str, Any]:
        """Run the blocking snapshot read off an async application's event loop."""
        return await asyncio.to_thread(self.load)

    async def async_load_readonly(self) -> dict[str, Any]:
        """Run :meth:`load_readonly` off an async application's event loop."""
        return await asyncio.to_thread(self.load_readonly)

    async def async_save(self, data: dict[str, Any]) -> None:
        """Run :meth:`save` off an async application's event loop."""
        await asyncio.to_thread(self.save, data)

    async def async_with_lock(self, fn: Callable[[dict[str, Any]], T]) -> T:
        """Run the synchronous, retrying mutation API off the event loop."""
        return await asyncio.to_thread(self.with_lock, fn)

    def with_lock(self, fn: Callable[[dict[str, Any]], T]) -> T:
        """Execute *fn* under local locking and transactional remote CAS.

        Firestore calls remain synchronous for compatibility. Async command
        paths must call this through an executor (see service adapters).
        ``fn`` may run again if another process commits first, so it must only
        mutate the supplied data and not perform external side effects.
        """
        with self.lock:
            for attempt in range(_MAX_WRITE_RETRIES):
                # Reuse a just-committed snapshot: the CAS version check in
                # _commit_diff catches any cross-process commit inside the
                # freshness window and the retry then fetches a fresh one.
                if (
                    attempt == 0
                    and self._cache is not None
                    and time.monotonic() - self._cache_ts < _WRITE_FRESHNESS_SECONDS
                ):
                    before = self._cache
                else:
                    # Do not mutate from the process cache: it can be stale after
                    # a different bot process commits.
                    before = self._load_from_firestore()
                version = self._version
                data = deepcopy(before)
                result = fn(data)
                try:
                    self._commit_diff(data, before, expected_version=version)
                except FirestoreStorageConflict:
                    if attempt + 1 == _MAX_WRITE_RETRIES:
                        raise
                    continue
                self._cache = data
                self._cache_ts = time.monotonic()
                self._readonly_cache = deepcopy(data)
                self._readonly_ts = time.monotonic()
                return result
        raise AssertionError("unreachable")
