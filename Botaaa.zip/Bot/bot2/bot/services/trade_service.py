"""Trade service backed by the Firestore trade repo with state-mirror compatibility."""

from __future__ import annotations

import asyncio
import time
from typing import Any

from bot.utils.timeutil import now_ts

# Minimum seconds between offer-expiry sweeps triggered by read paths.
# Prevents every `/trade board` read from running a full expire transaction set.
_EXPIRE_SWEEP_INTERVAL = 60.0


class TradeService:
    def __init__(self, repo: Any, storage: Any) -> None:
        self.repo = repo
        self.storage = storage
        self._last_expire_sweep = 0.0

    async def _storage_call(self, fn: Any) -> Any:
        """Keep synchronous FirestoreStorage I/O off the Discord event loop."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, fn)

    async def _storage_mutate(self, fn: Any) -> Any:
        return await self._storage_call(lambda: self.storage.with_lock(fn))

    async def mutate_state(self, fn: Any) -> Any:
        """Run an asset-state mutation without blocking the Discord loop."""
        return await self._storage_mutate(fn)

    async def bootstrap_from_json(self) -> None:
        if await self.repo.json_bootstrap_completed():
            return
        if await self.repo.has_persisted_state():
            await self.repo.mark_json_bootstrap_completed()
            return
        data = await self._storage_call(self.storage.load)
        trades = data.get("trades", {})
        if not isinstance(trades, dict):
            trades = {"pending": {}, "history": []}
        await self.repo.seed_from_json_trades(trades)
        await self.repo.mark_json_bootstrap_completed()

    async def is_pending(self, user_id: str) -> bool:
        return await self.repo.is_pending(user_id)

    async def add_pending_pair(self, a_id: str, b_id: str, *, mirror_json: bool = True) -> bool:
        """Atomically reserve both users as pending.

        Returns True if both were successfully inserted (neither was already
        pending).  Returns False if either was already pending.
        """
        inserted = await self.repo.add_pending_pair(a_id, b_id)
        if not inserted:
            return False
        if mirror_json:
            await self._storage_mutate(
                lambda d: d.setdefault("trades", {}).setdefault("pending", {}).update(
                    {str(a_id): True, str(b_id): True}
                )
            )
        return True

    async def remove_pending(self, user_id: str, *, mirror_json: bool = True) -> bool:
        ok = await self.repo.remove_pending(user_id)
        if ok and mirror_json:
            await self._storage_mutate(lambda d: d.setdefault("trades", {}).setdefault("pending", {}).pop(str(user_id), None))
        return ok

    async def remove_pending_pair(self, a_id: str, b_id: str, *, mirror_json: bool = True) -> None:
        await self.repo.remove_pending_pair(a_id, b_id)
        if not mirror_json:
            return
        await self._storage_mutate(
            lambda d: (
                d.setdefault("trades", {}).setdefault("pending", {}).pop(str(a_id), None),
                d.setdefault("trades", {}).setdefault("pending", {}).pop(str(b_id), None),
            )
        )

    async def clear_pending(self) -> int:
        count = await self.repo.clear_pending()
        await self._storage_mutate(lambda d: d.setdefault("trades", {}).__setitem__("pending", {}))
        return count

    @staticmethod
    def _json_truncate_history(d: dict[str, Any], row: dict[str, Any]) -> None:
        h = d.setdefault("trades", {}).setdefault("history", [])
        h.append(row)
        d["trades"]["history"] = h[-50:]

    async def append_history(self, row: dict[str, Any]) -> None:
        await self.repo.append_history(row)
        await self._storage_mutate(lambda d: self._json_truncate_history(d, row))

    async def history_for_user(self, user_id: str, limit: int = 20) -> list[dict[str, Any]]:
        return await self.repo.recent_history_for_user(user_id, limit=max(1, limit))

    async def hydrate_json_trade_state(self, data: dict[str, Any]) -> dict[str, Any]:
        t = data.setdefault("trades", {})
        if not isinstance(t, dict):
            data["trades"] = {"pending": {}, "history": []}
            t = data["trades"]
        t["pending"] = await self.repo.list_pending()
        return data

    async def post_offer(self, offer_id: str, poster_id: str, poster_name: str, have_card: str, want_card: str, item_uid: str, created_at: int, expires_at: int) -> None:
        await self.repo.post_offer(offer_id, poster_id, poster_name, have_card, want_card, item_uid, created_at, expires_at)

    async def get_open_offers(self, limit: int = 10) -> list[dict[str, Any]]:
        # Expired offers are already filtered out client-side by the repo, so
        # a sweep is only needed to unlock cards — rate-limit it to keep
        # the read path from triggering O(N) transactions per call.
        now = time.monotonic()
        if now - self._last_expire_sweep >= _EXPIRE_SWEEP_INTERVAL:
            self._last_expire_sweep = now
            await self.expire_offers()
        return await self.repo.get_open_offers(limit)

    async def cancel_offer(self, offer_id: str, poster_id: str) -> bool:
        return await self.repo.cancel_offer(offer_id, poster_id)

    async def claim_offer(self, offer_id: str) -> dict[str, Any] | None:
        return await self.repo.claim_offer(offer_id, now_ts())

    async def finish_offer(self, offer_id: str, *, accepted: bool) -> bool:
        return await self.repo.finish_offer(offer_id, "accepted" if accepted else "open")

    async def recover_stale_processing_offers(self) -> None:
        """Repair dead claims without reopening transfers already committed.

        The player-state transaction records a tiny receipt before the offer
        document is finalized.  That receipt closes the otherwise unavoidable
        crash window between moving the cards and changing offer status.
        """
        data = await self._storage_call(self.storage.load)
        trades = data.get("trades", {}) if isinstance(data, dict) else {}
        receipts = trades.get("offer_transfer_receipts", {}) if isinstance(trades, dict) else {}
        committed = set(receipts) if isinstance(receipts, dict) else set()
        await self.repo.recover_stale_processing_offers(committed)

    async def expire_offers(self) -> list[dict[str, Any]]:
        expired = await self.repo.expire_offers(now_ts())
        if not expired:
            return []

        expired_by_owner = {
            (str(row.get("poster_id", "")), str(row.get("item_uid", "")))
            for row in expired
        }

        def unlock(d: dict[str, Any]) -> None:
            players = d.get("players", {})
            if not isinstance(players, dict):
                return
            for owner_id, item_uid in expired_by_owner:
                player = players.get(owner_id, {})
                user = player.get("user", {}) if isinstance(player, dict) else {}
                inventory = user.get("inventory", []) if isinstance(user, dict) else []
                if not isinstance(inventory, list):
                    continue
                for item in inventory:
                    if isinstance(item, dict) and str(item.get("uid", "")) == item_uid:
                        item["trade_locked"] = False
                        break

        await self._storage_mutate(unlock)
        return expired
