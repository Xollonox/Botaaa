# Credential Exposure Response Runbook

> **Status: remediation is required; completion is unverified.** This document records
> verified *historical* exposures in reachable Git history. It does **not** assert that
> any credential has been rotated, that Git history has been scrubbed, or that any
> remote or fork has been updated. Treat every secret below as compromised until its
> owner records revocation, replacement, deployment, and validation.

A secret removed from the working tree or added to `.gitignore` remains available in
older commits, clones, caches, and forks. Rotation is the immediate containment step;
history rewriting is a separate cleanup step and does not revoke a leaked credential.

## Verified historical exposure inventory

The inventory was derived from tracked historical paths and names, without recording
secret values here. “Verified” means the named value was present in reachable history,
not that it is still valid or that it has been rotated.

| Bot | Historical location(s) | Secret requiring provider-side revocation/replacement | Notes |
| --- | --- | --- | --- |
| Bot1 | `Bot/bot1/.env` | `DISCORD_TOKEN`; `CEREBRAS_API_KEY`, `CEREBRAS_API_KEY_2`; `GROQ_API_KEY`, `GROQ_API_KEY_2`; `OLLAMA_API_KEY` through `OLLAMA_API_KEY_5`; `CLOUDFLARE_API_TOKEN` | All were tracked in the historical `.env`. |
| Bot1 | `Bot/bot1/.env.example` | `BLUESMINDS_API_KEY` | The BluesMinds key was committed in the historical example file. The current example must remain a placeholder only. |
| Bot2 | `Bot/bot2/.env`; historical `Bot/bot2/bot/config.py` | `BOT_TOKEN` | Bot2’s Discord token appeared in history. Current code loading an environment variable is not evidence that the old token was revoked. |
| Bot2 | historical `Bot/bot2/bot/data/supabase_sync.py` | `SUPABASE_KEY` / service-role key | The historical Supabase URL is context/metadata, not a credential to “rotate.” The sync module is no longer present, but that does not remove the historical exposure. |
| Bot3 (removed from current tree) | historical `Bot/bot3/.env` | `TESTER_TOKEN`; `DEEPSEEK_API_KEY` | Bot3 is absent from the current checkout, but its historical `.env` remains in reachable history and must be included in a scrub scope. |

`CLOUDFLARE_ACCOUNT_ID`, provider URLs, model names, user/owner IDs, paths, and log
settings may be sensitive operational metadata, but are not secrets with a provider
rotation action. Preserve no old values in examples or documentation.

No Firebase service-account private key, `FIREBASE_CREDENTIALS_JSON`, OpenRouter key,
or YouTube key is marked “verified exposed” by this inventory merely because those
variable names appear in source or placeholder documentation. Investigate any other
branches, tags, releases, CI logs, issue attachments, and hosting-provider findings
before declaring the inventory complete.

## Rotation: required, not yet verified

Perform provider-side revocation/replacement **before** history cleanup. Use the
provider dashboard or support process, then install the replacement only in the
relevant secret manager or untracked local `.env` file.

1. **Discord:** regenerate Bot1 `DISCORD_TOKEN`, Bot2 `BOT_TOKEN`, and removed Bot3
   `TESTER_TOKEN` at the Discord Developer Portal. Disable the old token where the
   provider permits it.
2. **Cerebras, Groq, and Ollama:** revoke every listed historical key and create only
   the replacements actually needed by Bot1.
3. **Cloudflare:** revoke and replace `CLOUDFLARE_API_TOKEN`. Do not describe the
   account ID as “rotated.”
4. **BluesMinds:** revoke and replace `BLUESMINDS_API_KEY`.
5. **Supabase:** revoke/regenerate the historical service-role key (`SUPABASE_KEY` /
   `SUPABASE_SERVICE_ROLE_KEY`) even though Bot2 no longer uses the mirror.
6. **DeepSeek:** revoke and replace `DEEPSEEK_API_KEY` if the account/key still exists.

Record each provider’s old-key revocation, new-key creation, secret-manager deployment,
and a minimal service health check in a restricted incident record. Do not put new
values, key fingerprints, or screenshots containing them in this repository.

### Rotation acceptance checklist

- [ ] Every inventory secret was revoked or explicitly confirmed already invalid by its provider.
- [ ] Replacement secrets were deployed from a secret manager or untracked `.env` files.
- [ ] Bot1 and Bot2 were tested with replacements; removed Bot3 is not deployed with its old token.
- [ ] Provider audit/activity logs were reviewed for suspicious use.
- [ ] The incident record contains evidence of the above.

Unchecked boxes are intentional: this repository currently has no evidence that these
steps have completed.

## Clean-mirror `git-filter-repo` procedure (plan; do not run in this checkout)

Use a disposable, access-controlled clone and coordinate a maintenance window. Keep an
unaltered forensic backup with access restricted; do not use it for normal development.
Do **not** rewrite or push until rotation is complete and the scrub result is reviewed.

1. Inventory all refs on the hosting provider: default and protected branches, tags,
   pull/merge-request refs, releases/source archives, wiki, packages, CI artifacts,
   deployment logs, and every fork. Record the canonical remote and the paths/secret
   values to remove in a restricted incident record.
2. Clone a clean mirror outside this working tree, and keep the original remote URL
   only in the incident record:
   ```bash
   git clone --mirror <canonical-remote-url> botaaa-scrub.git
   cd botaaa-scrub.git
   git show-ref --head
   ```
3. Install `git-filter-repo` in the isolated environment. Remove the tracked env files
   from every mirrored ref, including removed Bot3:
   ```bash
   git filter-repo --force --invert-paths \
     --path Bot/bot1/.env \
     --path Bot/bot2/.env \
     --path Bot/bot3/.env
   ```
4. Remove hardcoded historical secret values separately. Build a restricted
   `replacements.txt` containing exact leaked values (never commit it), then run
   `git filter-repo --replace-text /secure/path/replacements.txt`. Also remove or
   replace any additional path found by the pre-scrub scan. Path deletion alone cannot
   remove copied values in source, docs, logs, or other blobs.
5. Inspect the rewritten mirror before any push. Run a secret scanner configured with
   the known historical values/patterns against **all refs**, inspect tags and commits,
   and run `git fsck --full`. Confirm expected application files still exist and that
   `.env.example` files contain placeholders only.
6. Only after an authorized reviewer accepts the result, update the canonical remote
   with a coordinated force update (and temporarily adjust branch protection if needed).
   Announce new commit IDs, invalidate CI/build caches and release artifacts, and make
   all collaborators re-clone rather than merging old local history back.

`git-filter-repo` normally removes the `origin` remote as a safety measure. Re-add a
remote only after review, and only in the disposable mirror. This runbook does not
perform any of these commands or any push.

## Post-scrub and fork checks

A successful canonical rewrite does not delete copied objects. After the authorized
rewrite/push, verify all of the following:

- [ ] The canonical host’s branch, tag, pull/merge-request, release, and archive views
  no longer expose the paths or known secret patterns.
- [ ] A fresh clone of the canonical repository passes the same scanner; the local
  rewritten mirror also passes it for all refs.
- [ ] Every fork owner is notified to delete/recreate or independently scrub their
  fork. Forks cannot be rewritten by the upstream owner; assume any unconfirmed fork,
  clone, cache, or archive retains the old values.
- [ ] CI/CD variables, logs, artifacts, package registries, backups, chat attachments,
  and external code-search indexes were checked and purged or access-restricted.
- [ ] Old clones are retired and no one force-pushes or merges the pre-scrub history
  back into the canonical repository.
- [ ] Provider-side rotation remains complete. Scrubbing never substitutes for
  revocation.

## Environment examples

Use `Bot/bot1/.env.example` and `Bot/bot2/.env.example` only as placeholder templates.
Copy an example to an untracked `.env`, supply current secrets from an approved secret
store, and never copy historical values into either file. Bot3 has no current example
because that bot was removed; do not recreate its historical `.env`.
