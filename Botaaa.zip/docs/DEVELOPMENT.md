# Development and CI

## Install

Use the root requirements file to install both bots' runtime dependencies:

```bash
python -m pip install -r requirements.txt
```

For tests and quality checks, install the development requirements instead:

```bash
python -m pip install -r requirements-dev.txt
```

The root requirements file includes `Bot/bot1/requirements.txt` and
`Bot/bot2/requirements.txt`; do not duplicate bot dependencies in a third list.
Runtime, test, and quality-tool requirements are exact-pinned so a clean
install resolves the same direct dependency versions used in CI.

## Validate

Run the complete workspace suite from the repository root:

```bash
python -m pytest -q
```

CI also enforces these focused, low-noise checks:

```bash
python -m ruff check launcher.py tests Bot/bot2/bot/utils/logging_setup.py
python -m ruff format --check launcher.py tests Bot/bot2/bot/utils/logging_setup.py
python -m mypy launcher.py Bot/bot2/bot/utils/logging_setup.py
```

Failures are blocking on pushes and pull requests for Python 3.10 and 3.12.
Newer runs for the same branch or pull request cancel superseded runs.
Expand the lint/type-check scope only alongside fixes for the modules being
added; this keeps the initial enforcement baseline actionable.

## Operations

`launcher.py` supervises the configured bots (`BOTAAA_BOTS=bot1,bot2` by
default). On SIGINT or SIGTERM it stops restart backoff immediately, sends each
bot process group SIGINT, then escalates to SIGTERM and SIGKILL only after the
grace periods expire. Bot2 writes rotating logs to `Bot/bot2/logs/bot.log`
(10 MiB each, five retained backups).
