# 🚀 Deployment Guide

> **How to deploy Botaaa in various environments: local, VPS, and panel.**

---

## 1. 📋 Prerequisites

### Minimum Requirements
| Component | Requirement |
|-----------|-------------|
| Python | 3.10+ |
| RAM | 512MB (bot1+bot2), 256MB (single bot) |
| Storage | 500MB+ |
| Network | Outbound HTTPS (Discord API + AI providers) |
| Discord Bot Token | [Create in Developer Portal](https://discord.com/developers/applications) |
| Discord Intents | Message Content + Members + Server Members |

### Recommended
- **Firestore credentials:** Firebase service account key (see below)

### Bot2 Firestore Configuration
Bot2 persists all state to Firestore via the Firebase Admin SDK. Configure:

- `FIREBASE_PROJECT_ID` — Firestore project ID (required)
- One of:
  - `FIREBASE_CREDENTIALS_PATH` — filesystem path to the downloaded service account JSON, or
  - `FIREBASE_CREDENTIALS_JSON` — raw JSON contents of the key (useful on hosts where uploading a file is inconvenient)

Legacy: `LOOKISM_SQLITE_PATH` is retained only as a no-op env var; the SQLite backend was removed during the Firestore migration and this variable is now ignored. `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` are similarly unused by bot2.

---

## 2. 🏠 Local / Termux Deployment

### One-Command Setup
```bash
cd /data/data/com.termux/files/home/Botaaa
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python launcher.py
```

### With Environment Variables
```bash
set -a
source .env
set +a
python launcher.py
```

### Run Single Bot
```bash
# Miss Kim only
cd Bot/bot1
python main.py

# Lookism CG only
cd Bot/bot2
python main.py
```

### Termux-Specific Notes
- Run `pkg install python` if Python isn't installed
- Keep the terminal alive: use `tmux` or `nohup`

---

## 3. 🌐 VPS Deployment

### DigitalOcean / Linode / Hetzner

```bash
# 1. System update
apt update && apt upgrade -y
apt install -y python3 python3-pip python3-venv git tmux

# 2. Clone repo
git clone https://github.com/your-org/Botaaa.git
cd Botaaa

# 3. Virtual environment
python3 -m venv .venv
source .venv/bin/activate

# 4. Install deps
pip install -r requirements.txt

# 5. Create each bot's .env file (no secrets in repo!)
cp Bot/bot1/.env.example Bot/bot1/.env
cp Bot/bot2/.env.example Bot/bot2/.env
nano Bot/bot1/.env Bot/bot2/.env  # Add tokens and Firebase credentials

# 6. Run in tmux
tmux new -s botaaa
python launcher.py
# Ctrl+B, D to detach
# tmux attach -t botaaa to reattach
```

### Using systemd (Recommended for Production)
```ini
# /etc/systemd/system/botaaa.service
[Unit]
Description=Botaaa Discord Bot Suite
After=network.target

[Service]
Type=simple
User=botaaa
WorkingDirectory=/home/botaaa/Botaaa
EnvironmentFile=/home/botaaa/Botaaa/.env
ExecStart=/home/botaaa/Botaaa/.venv/bin/python /home/botaaa/Botaaa/launcher.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable botaaa
sudo systemctl start botaaa
sudo systemctl status botaaa

# View logs
sudo journalctl -u botaaa -f
```

---

## 4. 🎛️ Panel / Dashboard Deployment

### Pterodactyl / Pelican / Hosting Panels

**Startup Command:**
```bash
cd /home/container
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python launcher.py
```

**Important Panel Notes:**
1. **Persist data:** Bot2 state now lives in Firestore (remote), so no local data files need to be mounted. Ensure Firebase credentials are configured via env vars.
2. **Avoid dirty repo:** Set `git fetch origin main && git reset --hard origin/main` as deploy command
3. **Watch for:** `Bot/bot2/logs/bot.log` being tracked in git (make it ignored)
4. **Environment:** Set all tokens (Discord + Firebase credentials) as panel environment variables

**Safe Deploy Flow:**
```bash
git fetch origin main
git reset --hard origin/main
pip install -U -r requirements.txt --user
python launcher.py
```

---

## 5. 🔄 Update & Restart Procedures

### Zero-Downtime Updates (Theoretical)
```bash
# Bot2 stores state in Firestore, not in-memory
# Restarting is safe as long as:
1. No active battles (or they'll be auto-resolved as "abandoned")
2. No pending trades (or cards remain locked until restart cleanup)

# Best practice: announce maintenance, wait 5 min, then restart
```

### Full Restart
```bash
# If using launcher.py:
pkill -f "python.*launcher"  # SIGINT → graceful shutdown
python launcher.py

# If using systemd:
sudo systemctl restart botaaa

# If using tmux:
tmux kill-session -t botaaa
tmux new -s botaaa
python launcher.py
```

### Git-Based Update
```bash
# Safe pull + restart
git fetch origin main
git reset --hard origin/main
pip install -U -r requirements.txt
sudo systemctl restart botaaa
```

---

## 6. ☁️ Bot-Specific Deployment Options

### Running Bot1 Only (Miss Kim)
```bash
cd Bot/bot1
python main.py
# Requires: DISCORD_TOKEN in .env or env
# Works without: Cerebras, Groq, Ollama keys (will use fallback chain)
```

### Running Bot2 Only (Lookism CG)
```bash
cd Bot/bot2
python main.py
# Requires: BOT_TOKEN plus FIREBASE_PROJECT_ID and one credential variant
# (FIREBASE_CREDENTIALS_PATH or FIREBASE_CREDENTIALS_JSON).
# LOOKISM_OWNER_IDS is optional; without it, owner-only commands are disabled.
```

---

## 7. 📊 Monitoring

### Health Checks
```python
# Every 60 seconds, check:
# 1. Bot is connected to Discord Gateway
# 2. Firestore client is reachable
# 3. Background tasks are running
```

### Log Files
```
Bot/bot2/logs/bot.log  →  Runtime logs (check for errors)
journalctl -u botaaa   →  System-level logs
```

### Key Metrics to Monitor
| Metric | Warning | Critical |
|--------|---------|----------|
| Memory usage | >300MB | >500MB |
| CPU usage | >80% sustained | >95% |
| Response time (battle) | >3s | >8s |
| LLM failure rate | >10% | >30% |
| Firestore latency | >200ms typical | >1s sustained |
| Log file size | >100MB | >500MB |

---

## 8. 🐛 Troubleshooting

### Bot Won't Start
| Symptom | Cause | Fix |
|---------|-------|-----|
| `DISCORD_TOKEN not set` | No token in .env or config | Create .env with DISCORD_TOKEN |
| `PyNaCl not installed` | Voice module missing (safe to ignore) | Not needed |
| `ModuleNotFoundError` | Missing dependency | `pip install -r requirements.txt` |
| `Port already in use` | Another instance running | Kill existing: `pkill -f "python.*bot"` |

### Runtime Errors
| Symptom | Cause | Fix |
|---------|-------|-----|
| `could not reach AI backend` | All LLM providers down | Check provider status pages |
| `Battle error` | Bad state from crash | `/o_battle_unstuck` or restart |
| `Firestore permission denied` | Bad/missing credentials | Verify `FIREBASE_PROJECT_ID` and credential env var |
| `Firestore unavailable` | Network / quota | Check Firebase status and project quotas |
| `Card not found` | Missing in catalog | `/o add_card` or add to `cards.json` |

### Performance Issues
| Issue | Likely Cause | Solution |
|-------|-------------|----------|
| Slow battle responses | Storage lock contention or Firestore latency | Split hot subsystems into dedicated repos; check Firestore region |
| Image generation timeout | Cloudflare API slow | Switch to Pollinations (faster, lower quality) |
| Memory leak | `generated_image_messages` dict | Restart bot periodically |

---

## 9. 🔒 Production Security Checklist

- [ ] All secrets in `.env` (not in source files)
- [ ] `.gitignore` covers all sensitive files
- [ ] Git history cleaned of secrets (if ever exposed)
- [ ] Rate limiting configured on all commands
- [ ] Log rotation configured
- [ ] Firestore export / backup strategy in place
- [ ] Monitoring + alerting set up
- [ ] Graceful shutdown tested
- [ ] Disaster recovery plan documented

---

## 10. 💾 Backup Strategy

### Firestore Backups
Bot2 state now lives in Firestore. Use Firebase's export tooling (`gcloud firestore export`) or scheduled exports configured in the Firebase console. There is no local `lookism_data.json` / `lookism_data.sqlite3` to copy anymore.

### Manual Backup (bot1 only)
```bash
cp bot_memory.json bot_memory.json.bak
```

### Firestore Restore
```bash
gcloud firestore import gs://your-bucket/exports/EXPORT_NAME
sudo systemctl restart botaaa
```
