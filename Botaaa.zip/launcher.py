"""Start and supervise the bots that are configured for this workspace."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import threading
import time
from collections.abc import Iterable

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOT_ROOT = os.path.join(BASE_DIR, "Bot")
DEFAULT_BOT_DIRS = ["bot1", "bot2"]
REQUIRED_ENV = {
    "bot1": ("DISCORD_TOKEN",),
    # LOOKISM_OWNER_IDS is intentionally NOT required: config.py only warns
    # and owner commands get disabled (see tests/test_launcher.py).
    "bot2": ("BOT_TOKEN", "FIREBASE_PROJECT_ID"),
}
# bot2 additionally needs ONE of these credentials variants.
BOT2_FIREBASE_CRED_VARS = ("FIREBASE_CREDENTIALS_PATH", "FIREBASE_CREDENTIALS_JSON")

# Restart backoff: starts at BACKOFF_START, doubles per rapid crash, resets
# once a process stays up longer than STABLE_SECONDS.
BACKOFF_START = 10
BACKOFF_MAX = 300
STABLE_SECONDS = 60
SHUTDOWN_GRACE_SECONDS = 10
TERMINATE_GRACE_SECONDS = 5


def _load_env_file(path: str) -> dict[str, str]:
    values: dict[str, str] = {}
    if not os.path.exists(path):
        return values
    with open(path, encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            values[key.strip()] = value.strip().strip("'\"")
    return values


def _bot_names() -> list[str]:
    raw = os.getenv("BOTAAA_BOTS", "")
    if not raw.strip():
        return DEFAULT_BOT_DIRS
    return [name.strip() for name in raw.split(",") if name.strip()]


def _env_for_bot(bot_name: str) -> dict[str, str]:
    dotenv = _load_env_file(os.path.join(BOT_ROOT, bot_name, ".env"))
    return {**dotenv, **os.environ}


def _missing_required_env(bot_name: str, env: dict[str, str]) -> list[str]:
    missing = [key for key in REQUIRED_ENV.get(bot_name, ()) if not env.get(key)]
    if bot_name == "bot2" and not any(env.get(k) for k in BOT2_FIREBASE_CRED_VARS):
        missing.append("FIREBASE_CREDENTIALS_PATH or FIREBASE_CREDENTIALS_JSON")
    return missing


def start_bot(bot_name: str) -> subprocess.Popen[bytes] | None:
    bot_dir = os.path.join(BOT_ROOT, bot_name)
    script_path = os.path.join(bot_dir, "main.py")
    if not os.path.exists(script_path):
        print(f"[SKIP] {bot_name}: missing {script_path}")
        return None

    env = _env_for_bot(bot_name)
    missing = _missing_required_env(bot_name, env)
    if missing:
        print(f"[SKIP] {bot_name}: missing required env {', '.join(missing)}")
        return None

    try:
        # A dedicated session lets shutdown signal the bot and any children it
        # spawned, rather than leaving orphaned workers after a restart.
        proc = subprocess.Popen(
            [sys.executable, script_path],
            cwd=bot_dir,
            env=env,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"[ERROR] {bot_name}: could not start: {exc}")
        return None
    print(f"[STARTED] {bot_name} (pid={proc.pid})")
    return proc


def _signal_process(proc: subprocess.Popen[bytes], sig: int) -> None:
    """Signal a supervised process group, with a portable single-process fallback."""
    if proc.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(proc.pid, sig)
        else:
            proc.send_signal(sig)
    except ProcessLookupError:
        pass


def _wait_for_processes(processes: Iterable[subprocess.Popen[bytes]], timeout: float) -> None:
    """Reap processes within one shared timeout instead of serially waiting."""
    deadline = time.monotonic() + timeout
    for proc in processes:
        if proc.poll() is not None:
            continue
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return
        try:
            proc.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            continue


def shutdown_processes(processes: Iterable[subprocess.Popen[bytes]]) -> None:
    """Gracefully stop children, escalating only when they do not exit in time."""
    active = [proc for proc in processes if proc.poll() is None]
    if not active:
        return

    for proc in active:
        _signal_process(proc, signal.SIGINT)
    _wait_for_processes(active, SHUTDOWN_GRACE_SECONDS)

    active = [proc for proc in active if proc.poll() is None]
    for proc in active:
        _signal_process(proc, signal.SIGTERM)
    _wait_for_processes(active, TERMINATE_GRACE_SECONDS)

    for proc in active:
        if proc.poll() is None:
            _signal_process(proc, signal.SIGKILL)
    _wait_for_processes(active, TERMINATE_GRACE_SECONDS)


def main() -> None:
    procs: dict[str, subprocess.Popen[bytes]] = {}
    stopping = threading.Event()

    def request_shutdown(_signum: int, _frame: object) -> None:
        stopping.set()

    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGINT, request_shutdown)

    for name in _bot_names():
        proc = start_bot(name)
        if proc is not None:
            procs[name] = proc

    if not procs:
        print("No bots started. Add main.py inside a configured Bot/ directory")
        return

    backoff = {name: BACKOFF_START for name in procs}
    started_at = {name: time.monotonic() for name in procs}
    try:
        while procs and not stopping.is_set():
            for name, proc in list(procs.items()):
                code = proc.poll()
                if code is None:
                    continue

                if time.monotonic() - started_at.get(name, 0) > STABLE_SECONDS:
                    backoff[name] = BACKOFF_START
                delay = backoff.get(name, BACKOFF_START)
                print(f"[EXIT] {name} exited with code {code}. Restarting in {delay}s...")

                # Event.wait makes the backoff interruptible: Ctrl-C/SIGTERM
                # never causes one more bot restart before shutdown begins.
                if stopping.wait(delay):
                    break
                new_proc = start_bot(name)
                if new_proc is None:
                    del procs[name]
                    continue
                procs[name] = new_proc
                started_at[name] = time.monotonic()
                backoff[name] = min(delay * 2, BACKOFF_MAX)

            if not procs:
                print("All bots stopped.")
                break
            stopping.wait(1)
    finally:
        if stopping.is_set():
            print("\nStopping all bots...")
        shutdown_processes(procs.values())


if __name__ == "__main__":
    main()
