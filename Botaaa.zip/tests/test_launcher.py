import signal

import launcher

# Minimal runnable bot2 env: token + Firebase project + one credentials variant.
BOT2_BASE_ENV = {
    "BOT_TOKEN": "token",
    "FIREBASE_PROJECT_ID": "proj",
    "FIREBASE_CREDENTIALS_PATH": "/tmp/sa.json",
}


def test_bot2_owner_ids_accepts_comma_separated_numbers() -> None:
    env = {**BOT2_BASE_ENV, "LOOKISM_OWNER_IDS": "123, 456"}

    assert launcher._missing_required_env("bot2", env) == []


def test_bot2_owner_ids_accepts_alternate_env_names() -> None:
    env = {**BOT2_BASE_ENV, "BOT_OWNER_IDS": "123"}

    assert launcher._missing_required_env("bot2", env) == []


def test_bot2_does_not_require_owner_env() -> None:
    assert launcher._missing_required_env("bot2", dict(BOT2_BASE_ENV)) == []


def test_bot2_invalid_owner_env_does_not_block_startup() -> None:
    env = {**BOT2_BASE_ENV, "LOOKISM_OWNER_IDS": "abc"}

    assert launcher._missing_required_env("bot2", env) == []


def test_bot2_requires_firebase_project_id() -> None:
    env = {"BOT_TOKEN": "token", "FIREBASE_CREDENTIALS_PATH": "/tmp/sa.json"}

    assert launcher._missing_required_env("bot2", env) == ["FIREBASE_PROJECT_ID"]


def test_bot2_requires_a_firebase_credentials_variant() -> None:
    env = {"BOT_TOKEN": "token", "FIREBASE_PROJECT_ID": "proj"}

    assert launcher._missing_required_env("bot2", env) == [
        "FIREBASE_CREDENTIALS_PATH or FIREBASE_CREDENTIALS_JSON"
    ]


def test_bot2_accepts_credentials_json_variant() -> None:
    env = {
        "BOT_TOKEN": "token",
        "FIREBASE_PROJECT_ID": "proj",
        "FIREBASE_CREDENTIALS_JSON": "{}",
    }

    assert launcher._missing_required_env("bot2", env) == []


def test_bot2_reports_all_missing_firebase_vars() -> None:
    env = {"BOT_TOKEN": "token"}

    assert launcher._missing_required_env("bot2", env) == [
        "FIREBASE_PROJECT_ID",
        "FIREBASE_CREDENTIALS_PATH or FIREBASE_CREDENTIALS_JSON",
    ]


def test_default_launcher_includes_only_bots_in_this_workspace(monkeypatch) -> None:
    monkeypatch.delenv("BOTAAA_BOTS", raising=False)
    assert launcher._bot_names() == ["bot1", "bot2"]


class _Process:
    def __init__(self, pid: int = 123) -> None:
        self.pid = pid
        self.running = True
        self.wait_timeouts: list[float] = []

    def poll(self):
        return None if self.running else 0

    def wait(self, timeout: float) -> int:
        self.wait_timeouts.append(timeout)
        return 0

    def send_signal(self, _sig: int) -> None:
        self.running = False


def test_shutdown_signals_the_process_group_and_reaps_child(monkeypatch) -> None:
    process = _Process()
    signals: list[tuple[int, int]] = []

    def killpg(pid: int, sig: int) -> None:
        signals.append((pid, sig))
        process.running = False

    monkeypatch.setattr(launcher.os, "killpg", killpg)

    launcher.shutdown_processes([process])

    assert signals == [(123, signal.SIGINT)]
    # The child exited on SIGINT, so no escalation or blocking wait is needed.
    assert process.wait_timeouts == []


def test_signal_process_falls_back_when_group_is_already_gone(monkeypatch) -> None:
    process = _Process()

    def missing_group(_pid: int, _sig: int) -> None:
        raise ProcessLookupError

    monkeypatch.setattr(launcher.os, "killpg", missing_group)

    launcher._signal_process(process, signal.SIGTERM)
    assert process.running is True


def test_shutdown_escalates_for_a_process_that_ignores_signals(monkeypatch) -> None:
    process = _Process()
    signals: list[int] = []

    def killpg(_pid: int, sig: int) -> None:
        signals.append(sig)

    monkeypatch.setattr(launcher.os, "killpg", killpg)

    launcher.shutdown_processes([process])

    assert signals == [signal.SIGINT, signal.SIGTERM, signal.SIGKILL]
    assert len(process.wait_timeouts) == 3


def test_start_bot_creates_an_isolated_process_session(monkeypatch) -> None:
    calls: dict[str, object] = {}
    process = _Process(pid=456)

    def popen(*args, **kwargs):
        calls["args"] = args
        calls["kwargs"] = kwargs
        return process

    monkeypatch.setattr(launcher, "_env_for_bot", lambda _name: {"DISCORD_TOKEN": "token"})
    monkeypatch.setattr(launcher.subprocess, "Popen", popen)

    assert launcher.start_bot("bot1") is process
    bot_dir = launcher.os.path.join(launcher.BOT_ROOT, "bot1")
    command = [launcher.sys.executable, launcher.os.path.join(bot_dir, "main.py")]
    assert calls["args"] == (command,)
    assert calls["kwargs"] == {
        "cwd": bot_dir,
        "env": {"DISCORD_TOKEN": "token"},
        "start_new_session": True,
    }
