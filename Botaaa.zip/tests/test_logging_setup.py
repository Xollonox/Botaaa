import logging
from logging.handlers import RotatingFileHandler

from bot.utils.logging_setup import LOG_BACKUP_COUNT, LOG_MAX_BYTES, setup_logging


def test_setup_logging_uses_one_rotating_file_handler(tmp_path) -> None:
    root = logging.getLogger()
    original_handlers = root.handlers[:]
    original_level = root.level
    root.handlers.clear()
    try:
        setup_logging(tmp_path)
        setup_logging(tmp_path)

        handlers = [
            handler
            for handler in root.handlers
            if getattr(handler, "_botaaa_handler", None) == "file"
        ]
        assert len(handlers) == 1
        handler = handlers[0]
        assert isinstance(handler, RotatingFileHandler)
        assert handler.baseFilename == str(tmp_path / "bot.log")
        assert handler.maxBytes == LOG_MAX_BYTES
        assert handler.backupCount == LOG_BACKUP_COUNT
    finally:
        for handler in root.handlers:
            handler.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)
